#!/usr/bin/env python3
"""One-shot X RSS -> Telegram worker; systemd timer supplies the schedule."""
from contextlib import closing
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET

ACCOUNT = 'CoinWOfficial'
CHANNEL = '@coinwofficialchannel'
BOT = 'CoinWCommunityHubBot'
FEED = 'http://127.0.0.1:1200/twitter/user/' + ACCOUNT
STATE = Path('/var/lib/coinw-x-forward')
PUBLIC = Path('/var/lib/coinw-x-status/status.json')
REQUESTS = Path('/var/lib/coinw/x-forward-requests')


class Failure(Exception):
    pass


class TelegramFailure(Failure):
    def __init__(self, kind, delay=0, detail=''):
        super().__init__(kind)
        self.kind, self.delay = kind, delay
        self.detail = detail or kind


class Content(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.images, self.hidden = [], [], 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ('script', 'style'):
            self.hidden += 1
        if self.hidden:
            return
        if tag in ('p', 'div', 'br'):
            self.parts.append('\n')
        if tag == 'a':
            href = attrs.get('href', '')
            if href.startswith(('https://', 'http://')):
                self.parts.append(' ' + href + ' ')
        if tag == 'img':
            src = attrs.get('src', '')
            url = urlsplit(src)
            # Telegram downloads public X images; never forward arbitrary local URLs.
            if url.scheme == 'https' and url.hostname == 'pbs.twimg.com' and not url.username and url.port in (None, 443):
                if src not in self.images:
                    self.images.append(src)

    def handle_endtag(self, tag):
        if tag in ('script', 'style') and self.hidden:
            self.hidden -= 1
        if tag in ('p', 'div') and not self.hidden:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def parse_feed(body):
    if len(body) > 2_000_000 or b'<!DOCTYPE' in body.upper() or b'<!ENTITY' in body.upper():
        raise Failure('feed_rejected')
    try:
        root = ET.fromstring(body)
        if root.tag != 'rss':
            raise ValueError()
        posts = {}
        for item in root.findall('./channel/item'):
            url = urlsplit(item.findtext('link', '').strip())
            match = re.fullmatch(r'/CoinWOfficial/status/(\d+)/?', url.path, re.I)
            if url.hostname not in ('x.com', 'twitter.com', 'www.x.com', 'www.twitter.com') or not match:
                continue
            date = parsedate_to_datetime(item.findtext('pubDate', ''))
            if date.tzinfo is None:
                raise ValueError()
            content = Content()
            content.feed(item.findtext('description', '') or item.findtext('title', ''))
            text = '\n'.join(re.sub(r'[ \t]+', ' ', line).strip() for line in ''.join(content.parts).splitlines()).strip()
            if not text and not content.images:
                continue
            pid = match[1]
            posts[pid] = dict(id=pid, published=date.timestamp(), text=text, images=content.images,
                              url=f'https://x.com/{ACCOUNT}/status/{pid}')
        if not posts:
            raise ValueError()
        return sorted(posts.values(), key=lambda post: (post['published'], int(post['id'])))
    except (ValueError, TypeError, OverflowError, ET.ParseError):
        raise Failure('feed_invalid_or_no_posts') from None


def fetch_feed():
    try:
        # Only the fixed loopback RSSHub endpoint bypasses outbound proxies.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(FEED, timeout=60) as response:
            body = response.read(2_000_001)
        return parse_feed(body)
    except (OSError, ValueError):
        raise Failure('rsshub_unavailable_check_login_or_rate_limit') from None


def telegram(token, method, data):
    if not re.fullmatch(r'\d+:[\w-]+', token, re.ASCII):
        raise Failure('existing_telegram_token_missing')
    request = urllib.request.Request('https://api.telegram.org/bot' + token + '/' + method,
                                     data=json.dumps(data).encode(), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            result = json.loads(response.read(1_000_000))
    except urllib.error.HTTPError as error:
        if error.code == 429:
            try:
                delay = int(json.loads(error.read(65536)).get('parameters', {}).get('retry_after', 600))
            except (ValueError, TypeError, OSError):
                delay = 600
            raise TelegramFailure('rate_limited', max(600, delay), 'http_429') from None
        raise TelegramFailure('uncertain' if error.code >= 500 else 'rejected', detail='http_'+str(error.code)) from None
    except (OSError, ValueError) as error:
        # Telegram may have accepted a timed-out request. Never blindly resend.
        timeout = isinstance(error, TimeoutError) or (isinstance(error, urllib.error.URLError) and isinstance(error.reason, TimeoutError))
        detail = 'request_timeout' if timeout else 'invalid_response' if isinstance(error, ValueError) else 'connection_error'
        raise TelegramFailure('uncertain', detail=detail) from None
    if not isinstance(result, dict):
        raise TelegramFailure('uncertain', detail='invalid_response')
    if not result.get('ok'):
        if result.get('error_code') == 429:
            raise TelegramFailure('rate_limited', max(600, int(result.get('parameters', {}).get('retry_after', 600))))
        code = result.get('error_code')
        raise TelegramFailure('rejected', detail='http_'+str(code) if type(code) is int and 400<=code<=599 else 'rejected')
    if 'result' not in result:
        raise TelegramFailure('uncertain', detail='invalid_response')
    return result['result']


def preflight(call):
    me = call('getMe', {})
    if me.get('username', '').lower() != BOT.lower():
        raise Failure('unexpected_bot')
    chat = call('getChat', {'chat_id': CHANNEL})
    if chat.get('type') != 'channel' or chat.get('username', '').lower() != CHANNEL[1:].lower():
        raise Failure('unexpected_channel')
    member = call('getChatMember', {'chat_id': chat['id'], 'user_id': me['id']})
    if member.get('status') != 'creator' and not (member.get('status') == 'administrator' and member.get('can_post_messages')):
        raise Failure('bot_cannot_post')


def chunks(text, limit=3900):
    result, part, size = [], '', 0
    for char in text:
        width = 2 if ord(char) > 0xffff else 1
        if size + width > limit:
            result.append(part)
            part, size = '', 0
        part += char
        size += width
    if part:
        result.append(part)
    return result


def plan(post):
    button = {'inline_keyboard': [[{'text': 'View on X', 'url': post['url']}]]}
    steps = []
    text = post['text']
    caption = text if len(text.encode('utf-16-le')) // 2 <= 1000 and post['images'] else ''
    if text and not caption:
        for part in chunks(text):
            steps.append(('sendMessage', {'chat_id': CHANNEL, 'text': part, 'reply_markup': button,
                                          'link_preview_options': {'is_disabled': True}}))
    for index, image in enumerate(post['images']):
        data = {'chat_id': CHANNEL, 'photo': image, 'reply_markup': button}
        if index == 0 and caption:
            data['caption'] = caption
        steps.append(('sendPhoto', data))
    return steps


def connect(path):
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.executescript('''
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS posts(id TEXT PRIMARY KEY,payload TEXT NOT NULL,status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS deliveries(post_id TEXT,part INTEGER,status TEXT NOT NULL,message_id INTEGER,
            PRIMARY KEY(post_id,part));
        CREATE TABLE IF NOT EXISTS manual_requests(id TEXT PRIMARY KEY,post_id TEXT,actor TEXT,action TEXT,
            status TEXT,detail TEXT,created REAL,completed REAL);
        CREATE TABLE IF NOT EXISTS delivery_history(request_id TEXT,post_id TEXT,part INTEGER,status TEXT,
            message_id INTEGER,archived_at REAL,PRIMARY KEY(request_id,part));
    ''')
    return db


def get(db, key, default='0'):
    row = db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return row[0] if row else default


def put(db, key, value):
    db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)', (key, str(value)))


def initialize(db, posts, now):
    if get(db, 'enabled_at', ''):
        return False
    # Starting/reinstalling must never backfill feed history.
    with db:
        put(db, 'enabled_at', now)
        put(db, 'next_fetch', now + 600)
        for post in posts:
            db.execute('INSERT OR IGNORE INTO posts VALUES(?,?,?)', (post['id'], json.dumps(post), 'baseline'))
    return True


def stage_posts(db, posts, now):
    if not get(db, 'enabled_at', ''):
        raise Failure('not_initialized')
    with db:
        # Durable sending marker survives process death; uncertain sends require manual inspection.
        for row in db.execute("SELECT post_id,part FROM deliveries WHERE status='sending'").fetchall():
            put(db, 'delivery_error_'+row['post_id']+'_'+str(row['part']), 'worker_interrupted')
        db.execute("UPDATE deliveries SET status='uncertain' WHERE status='sending'")
        for post in posts:
            if float(get(db, 'enabled_at')) < post['published'] <= now + 60:
                db.execute('INSERT OR IGNORE INTO posts VALUES(?,?,?)', (post['id'], json.dumps(post), 'pending'))


def cycle(db, posts, call, now, only_post=None):
    stage_posts(db, posts, now)
    if now < float(get(db, 'next_send')):
        return
    for row in db.execute("SELECT * FROM posts WHERE status='pending' ORDER BY CAST(id AS INTEGER)").fetchall():
        if only_post is not None and row['id'] != only_post:
            continue
        # Quarantine the whole affected post, including unattempted parts. Other
        # posts remain deliverable; uncertain content is never blindly replayed.
        if db.execute("SELECT 1 FROM deliveries WHERE post_id=? AND status IN ('uncertain','failed')", (row['id'],)).fetchone():
            if only_post is not None:
                raise Failure('delivery_requires_inspection_post_' + row['id'])
            continue
        steps = plan(json.loads(row['payload']))
        for index, (method, data) in enumerate(steps):
            delivery = db.execute('SELECT status FROM deliveries WHERE post_id=? AND part=?', (row['id'], index)).fetchone()
            if delivery and delivery[0] == 'sent':
                continue
            if delivery and delivery[0] in ('uncertain', 'failed'):
                raise Failure('delivery_requires_inspection_post_' + row['id'])
            with db:
                db.execute('INSERT OR REPLACE INTO deliveries VALUES(?,?,?,NULL)', (row['id'], index, 'sending'))
            try:
                result = call(method, data)
                if not isinstance(result, dict) or not isinstance(result.get('message_id'), int):
                    raise TelegramFailure('uncertain')
            except TelegramFailure as error:
                with db:
                    status = {'rate_limited': 'retry', 'rejected': 'failed'}.get(error.kind, 'uncertain')
                    db.execute('UPDATE deliveries SET status=? WHERE post_id=? AND part=?', (status, row['id'], index))
                    put(db, 'delivery_error_'+row['id']+'_'+str(index), error.detail)
                    if error.delay:
                        put(db, 'next_send', now + error.delay)
                raise Failure('telegram_' + error.kind + '_post_' + row['id']) from None
            with db:
                db.execute("UPDATE deliveries SET status='sent',message_id=? WHERE post_id=? AND part=?", (result['message_id'], row['id'], index))
                put(db, 'delivery_error_'+row['id']+'_'+str(index), '')
        with db:
            db.execute("UPDATE posts SET status='sent' WHERE id=?", (row['id'],))
            put(db, 'last_delivery', time.time())
        print('Forwarded post ' + row['id'], flush=True)


def run_once(db, call, now):
    """Read the source on its own schedule; drain safe cached work independently."""
    if not get(db, 'enabled_at', ''):
        raise Failure('not_initialized')
    posts=[]
    source_error=get(db, 'last_feed_error', '')
    if now >= float(get(db, 'next_fetch')):
        with db:
            put(db, 'next_fetch', now + 600)
            put(db, 'last_check', now)
        try:
            posts=fetch_feed()
        except Failure as error:
            source_error=str(error)
            with db:
                failures=int(get(db, 'feed_failures'))+1
                put(db, 'feed_failures', failures)
                put(db, 'last_feed_error', source_error)
                put(db, 'next_fetch', now + min(21600, 600 * 2 ** min(failures, 5)))
        else:
            source_error=''
            with db:
                put(db, 'feed_failures', 0)
                put(db, 'last_feed_error', '')
                put(db, 'last_fetch_success', now)
    stage_posts(db, posts, now)
    ready=db.execute("""SELECT 1 FROM posts p WHERE p.status='pending' AND NOT EXISTS
        (SELECT 1 FROM deliveries d WHERE d.post_id=p.id AND d.status IN ('failed','uncertain','sending')) LIMIT 1""").fetchone()
    if ready and now >= float(get(db, 'next_send')):
        try:
            preflight(call)
        except TelegramFailure as error:
            raise Failure('telegram_preflight_'+error.kind) from None
        cycle(db, [], call, now)
    # Source errors remain visible even when cached posts were delivered.
    if source_error:
        raise Failure(source_error)
    with db:
        put(db, 'last_success', now)
        put(db, 'last_error', '')
    print('Forwarding check completed. Flagged posts remain isolated for review.', flush=True)


def revision(db, pid):
    row = db.execute('SELECT status FROM posts WHERE id=?', (pid,)).fetchone()
    deliveries = [tuple(item) for item in db.execute('SELECT part,status,message_id FROM deliveries WHERE post_id=? ORDER BY part', (pid,))]
    return hashlib.sha256(json.dumps([row[0] if row else None, deliveries, get(db, 'manual_generation_'+pid)]).encode()).hexdigest()


def process_request(db, request, call, now):
    """Only fixed post operations, serialized with the automatic worker's lock."""
    rid, pid = request['id'], request['post_id']
    if db.execute('SELECT 1 FROM manual_requests WHERE id=?', (rid,)).fetchone():
        return
    with db:
        db.execute('INSERT INTO manual_requests VALUES(?,?,?,?,?,?,?,NULL)',
                   (rid, pid, request['actor'], request['action'], 'processing', '', now))
    try:
        row = db.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone()
        if row is None:
            raise Failure('post_not_found')
        if revision(db, pid) != request['revision']:
            raise Failure('post_changed_refresh')
        if row['status'] == 'sent' and request['action'] != 'republish':
            raise Failure('already_sent')
        if request['action'] == 'republish' and (row['status'] != 'sent' or request.get('confirmed') is not True):
            raise Failure('confirm_republish_completed_post')
        with db:
            put(db, 'manual_generation_'+pid, int(get(db, 'manual_generation_'+pid))+1)
        if now < float(get(db, 'next_send')):
            raise Failure('manual_rate_limit_wait')
        ambiguous = db.execute("SELECT 1 FROM deliveries WHERE post_id=? AND status IN ('sending','uncertain')", (pid,)).fetchone()
        if ambiguous and request.get('confirmed') is not True:
            raise Failure('confirm_channel_first')
        # Permission failures must leave the prior successful deliveries intact.
        preflight(call)
        if request['action'] == 'mark_sent':
            if not ambiguous:
                raise Failure('no_uncertain_parts')
            with db:
                db.execute("UPDATE deliveries SET status='sent' WHERE post_id=? AND status IN ('sending','uncertain')", (pid,))
        elif request['action'] == 'publish':
            with db:
                db.execute("UPDATE deliveries SET status='retry' WHERE post_id=? AND status IN ('failed','uncertain','sending')", (pid,))
        elif request['action'] == 'republish':
            with db:
                db.execute('INSERT INTO delivery_history SELECT ?,post_id,part,status,message_id,? FROM deliveries WHERE post_id=?', (rid,now,pid))
                db.execute('DELETE FROM deliveries WHERE post_id=?', (pid,))
                db.execute("UPDATE posts SET status='pending' WHERE id=?", (pid,))
        else:
            raise Failure('invalid_action')
        with db:
            db.execute("UPDATE posts SET status='pending' WHERE id=?", (pid,))
        # Uses stored validated content, never fetches X or accepts client text/URLs/tokens.
        cycle(db, [], call, now, only_post=pid)
        with db:
            db.execute("UPDATE manual_requests SET status='completed',detail='sent',completed=? WHERE id=?", (time.time(), rid))
            blocked = db.execute("SELECT 1 FROM deliveries WHERE status IN ('failed','uncertain','sending')").fetchone()
            if not blocked and ('telegram_' in get(db,'last_error','') or get(db,'last_error','').startswith('delivery_requires_inspection')):
                put(db,'last_error','')
    except Failure as error:
        with db:
            db.execute("UPDATE manual_requests SET status='failed',detail=?,completed=? WHERE id=?", (str(error), time.time(), rid))


def process_queue(db, call):
    with db:
        db.execute("UPDATE manual_requests SET status='interrupted',detail='check_channel_before_retry',completed=? WHERE status='processing'", (time.time(),))
    for path in sorted(REQUESTS.glob('*.json'))[:50]:
        if not re.fullmatch(r'[a-f0-9]{32}\.json', path.name):
            continue
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, 'rb') as stream:
                raw = stream.read(8193)
            if len(raw) > 8192:
                raise ValueError()
            request = json.loads(raw)
            if (request['id'] != path.stem or not re.fullmatch(r'\d{1,30}', request['post_id'])
                    or not re.fullmatch(r'[a-f0-9]{64}', request['revision'])
                    or request['action'] not in ('publish','mark_sent','republish')
                    or not isinstance(request['actor'],str) or len(request['actor']) > 100):
                raise ValueError()
            process_request(db, request, call, time.time())
        except (ValueError, TypeError, KeyError, OSError):
            print('Invalid manual request ignored.', flush=True)
        finally:
            path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('initialize', 'run', 'status', 'preflight', 'manual'))
    args = parser.parse_args()
    token = os.environ.get('TG_BOT_TOKEN', '')
    call = lambda method, data: telegram(token, method, data)
    if args.action == 'preflight':
        preflight(call)
        print('Verified bot identity and channel posting permission; no message sent.')
        return
    STATE.mkdir(mode=0o700, parents=True, exist_ok=True)
    with (STATE / 'worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX if args.action == 'manual' else fcntl.LOCK_EX | fcntl.LOCK_NB)
        with closing(connect(STATE / 'forward.sqlite3')) as db:
            with db:
                db.execute("UPDATE manual_requests SET status='interrupted',detail='check_channel_before_retry',completed=? WHERE status='processing'", (time.time(),))
            if args.action == 'manual':
                process_queue(db, call)
                return
            if args.action == 'status':
                print('Enabled at UTC:', datetime.fromtimestamp(float(get(db, 'enabled_at')), timezone.utc).isoformat())
                print('Post states:', dict(db.execute('SELECT status,COUNT(*) FROM posts GROUP BY status').fetchall()))
                print('Delivery states:', dict(db.execute('SELECT status,COUNT(*) FROM deliveries GROUP BY status').fetchall()))
                return
            now = time.time()
            if args.action == 'initialize':
                if get(db, 'enabled_at', ''):
                    print('Existing activation and delivery history preserved.')
                    return
                preflight(call)
                posts = fetch_feed()
                if not any(now - 7 * 86400 <= post['published'] <= now + 60 for post in posts):
                    raise Failure('feed_has_no_recent_posts')
                if initialize(db, posts, now):
                    print('Baseline saved. Only posts published after this activation will be sent.')
                else:
                    print('Existing activation and delivery history preserved.')
            else:
                run_once(db, call, now)


def publish_status(error=None):
    """Publish only curated public-post metadata, never credentials or raw responses."""
    if not (STATE / 'forward.sqlite3').is_file():
        return
    with closing(connect(STATE / 'forward.sqlite3')) as db:
        if error:
            with db:
                put(db, 'last_error', error)
                put(db, 'last_error_at', time.time())
        report = {'version': 1, 'updated_at': time.time(), 'source': ACCOUNT, 'channel': CHANNEL,
                  'bot': BOT, 'interval_seconds': 600,
                  'counts': dict(db.execute('SELECT status,COUNT(*) FROM posts GROUP BY status').fetchall()),
                  'delivery_counts': dict(db.execute('SELECT status,COUNT(*) FROM deliveries GROUP BY status').fetchall()),
                  'posts': []}
        report['isolated_delivery_errors'] = True
        report['manual_supported'] = True
        report['republish_supported'] = True
        report['requests'] = [dict(item) for item in db.execute('SELECT * FROM manual_requests ORDER BY created DESC LIMIT 50')]
        for key in ('enabled_at', 'last_check', 'last_success', 'last_delivery', 'next_fetch', 'next_send', 'last_error_at', 'last_fetch_success'):
            report[key] = float(get(db, key))
        report['last_error'] = get(db, 'last_error', '')
        report['last_feed_error'] = get(db, 'last_feed_error', '')
        for row in db.execute('SELECT * FROM posts ORDER BY CAST(id AS INTEGER) DESC LIMIT 100'):
            post = json.loads(row['payload'])
            deliveries = [dict(item) for item in db.execute('SELECT part,status,message_id FROM deliveries WHERE post_id=? ORDER BY part', (row['id'],))]
            for delivery in deliveries:
                delivery['detail'] = get(db, 'delivery_error_'+row['id']+'_'+str(delivery['part']), '') if delivery['status']!='sent' else ''
            history = [dict(item) for item in db.execute('SELECT part,message_id,archived_at FROM delivery_history WHERE post_id=? ORDER BY archived_at DESC,part LIMIT 20', (row['id'],))]
            report['posts'].append({'id': row['id'], 'published': post['published'], 'text': post['text'][:1200],
                                    'images': len(post['images']), 'status': row['status'], 'deliveries': deliveries,
                                    'revision':revision(db,row['id']), 'previous_deliveries':history})
    PUBLIC.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    PUBLIC.parent.chmod(0o755)
    fd, filename = tempfile.mkstemp(dir=PUBLIC.parent, prefix='.status-')
    try:
        with os.fdopen(fd, 'w') as output:
            os.fchmod(output.fileno(), 0o644)
            json.dump(report, output, ensure_ascii=False)
            output.flush()
            os.fsync(output.fileno())
        os.replace(filename, PUBLIC)
    finally:
        Path(filename).unlink(missing_ok=True)


if __name__ == '__main__':
    os.umask(0o077)
    failure = None
    try:
        main()
    except BlockingIOError:
        print('Another forwarding operation is active; check deferred.', flush=True)
    except (Failure, OSError, ValueError, sqlite3.Error) as error:
        # API errors can include token-bearing URLs. Never print arbitrary exceptions.
        failure = str(error) if isinstance(error, Failure) else 'local_runtime_error'
        print('Stopped: ' + failure, flush=True)
        raise SystemExit(1)
    finally:
        if len(sys.argv) > 1 and sys.argv[1] in ('run', 'initialize', 'manual'):
            try:
                publish_status(failure)
            except (OSError, ValueError, sqlite3.Error):
                print('Status report could not be published.', flush=True)
