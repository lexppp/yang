#!/usr/bin/env python3
"""Apply the focused X forwarding recovery update to the existing server."""
from contextlib import closing
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request

SOURCE=Path(__file__).resolve().parents[1]
APP=Path('/opt/coinw')
FORWARD=Path('/opt/coinw-x-forward')
STATE=Path('/var/lib/coinw-x-forward')
BACKUPS=Path('/var/lib/coinw/code-backups')
UNITS=Path('/etc/systemd/system')
TRIGGERS=('coinw-x-forward.timer','coinw-x-manual.path')
MARKER='# Managed by CoinW X forward installer v1\n'
NAMES={'deploy/x_to_telegram.py','sync_status.py','static/sync.js',
       'deploy/install_sync_recovery.py','deploy/SYNC_RECOVERY.md'}


def command(args):
    result=subprocess.run(args,capture_output=True,timeout=45)
    if result.returncode:raise ValueError('Service operation failed; previous configuration was preserved.')


def active(unit):
    return subprocess.run(['systemctl','is-active','--quiet',unit],capture_output=True,timeout=5).returncode==0


def atomic(path,body):
    fd,temporary=tempfile.mkstemp(dir=path.parent,prefix='.sync-recovery-')
    try:
        with os.fdopen(fd,'wb') as stream:
            os.fchmod(stream.fileno(),0o644);stream.write(body);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
    finally:Path(temporary).unlink(missing_ok=True)


def publish_status():
    command([sys.executable,'-c',"import runpy; runpy.run_path("+repr(str(FORWARD/'x_to_telegram.py'))+")[\"publish_status\"]()"])


def readiness(asset):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(50):
        try:
            with opener.open('http://127.0.0.1:8000/health',timeout=1) as response:
                if json.load(response).get('ok'):break
        except OSError:time.sleep(.2)
    else:raise ValueError('Website did not become ready; restoring previous code.')
    with opener.open('http://127.0.0.1:8000/sync.js',timeout=3) as response:
        if response.read(200000)!=asset:raise ValueError('Updated page was not served; restoring previous code.')


def install():
    if os.geteuid()!=0:raise ValueError('Run sudo python3 deploy/install_sync_recovery.py')
    manifest=json.loads((SOURCE/'deploy/sync-recovery-release.json').read_text())
    if manifest.get('version')!=1 or set(manifest.get('files',{}))!=NAMES:raise ValueError('Unexpected bundle manifest.')
    contents={}
    for name,digest in manifest['files'].items():
        body=(SOURCE/name).read_bytes()
        if hashlib.sha256(body).hexdigest()!=digest:raise ValueError('Bundle checksum mismatch; nothing installed.')
        if name.endswith('.py'):compile(body,name,'exec')
        contents[name]=body
    targets={FORWARD/'x_to_telegram.py':contents['deploy/x_to_telegram.py'],
             APP/'sync_status.py':contents['sync_status.py'],APP/'static/sync.js':contents['static/sync.js']}
    for directory in (APP,APP/'static',FORWARD,STATE):
        if directory.is_symlink() or not directory.is_dir():raise ValueError('Expected existing server directories.')
    for path in (*targets,STATE/'forward.sqlite3',UNITS/'coinw-x-forward.service'):
        if path.is_symlink() or not path.is_file():raise ValueError('Expected existing installation files.')
    if not (UNITS/'coinw-x-forward.service').read_text().startswith(MARKER):raise ValueError('Forward service is not managed by the existing installer.')
    with closing(sqlite3.connect('file:'+str(STATE/'forward.sqlite3')+'?mode=ro',uri=True)) as db:
        if not db.execute("SELECT 1 FROM meta WHERE key='enabled_at'").fetchone():raise ValueError('Forwarding has not been activated.')
    states={unit:active(unit) for unit in (*TRIGGERS,'coinw')}
    previous={path:path.read_bytes() for path in targets}
    print('Verified recovery update. Waiting for any current forwarding request to finish.',flush=True)
    with (STATE/'worker.lock').open('a') as lock:
        changed=False
        try:
            for unit in TRIGGERS:
                if states[unit]:command(['systemctl','stop',unit])
            deadline=time.monotonic()+30
            while True:
                try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
                except BlockingIOError:
                    if time.monotonic()>=deadline:raise ValueError('Worker is busy; retry after the current operation finishes.')
                    time.sleep(.2)
            backup=BACKUPS/('sync-recovery-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'))
            backup.mkdir(parents=True,mode=0o700)
            for index,body in enumerate(previous.values()):(backup/(str(index)+'.bin')).write_bytes(body)
            (backup/'files.json').write_text(json.dumps([str(path) for path in previous]))
            with closing(sqlite3.connect(STATE/'forward.sqlite3')) as source,closing(sqlite3.connect(backup/'forward.sqlite3')) as dest:
                source.backup(dest)
            (backup/'forward.sqlite3').chmod(0o600)
            command(['systemctl','stop','coinw'])
            changed=True
            for path,body in targets.items():atomic(path,body)
            publish_status()
            if states['coinw']:
                command(['systemctl','start','coinw']);readiness(contents['static/sync.js'])
        except BaseException:
            if changed:
                subprocess.run(['systemctl','stop','coinw'],capture_output=True)
                for path,body in previous.items():atomic(path,body)
                try:publish_status()
                except Exception:pass
            if states['coinw']:subprocess.run(['systemctl','start','coinw'],capture_output=True)
            raise
        finally:
            for unit in TRIGGERS:
                if states[unit]:command(['systemctl','start',unit])
    print('Recovery installed. Accounts, X login, databases and delivery history were preserved.',flush=True)
    print('Flagged posts remain isolated. Other cached pending posts can continue; successful parts will not be replayed.')
    if states['coinw-x-forward.timer']:
        command(['systemctl','start','--no-block','coinw-x-forward.service'])
        print('Forwarding check requested. Actual delivery depends on Telegram availability and rate limits.')
    print('Open https://panel.chloehub.top/?v=sync-recovery#sync and refresh the page.')


if __name__=='__main__':
    os.umask(0o077)
    try:install()
    except KeyboardInterrupt:
        print('Update cancelled. Check the preceding fixed status messages.',file=sys.stderr);sys.exit(130)
    except Exception:
        print('Update stopped. Check bundle verification, existing installation and service readiness. No credentials were displayed.',file=sys.stderr);sys.exit(1)
