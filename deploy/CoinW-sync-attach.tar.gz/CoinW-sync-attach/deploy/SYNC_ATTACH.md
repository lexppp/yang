# 将缺失媒体补到原消息

适用于已安装 CoinW X→Telegram 同步器的服务器，包含此前 GIF／MP4 支持。只更新独立转发器 x_to_telegram.py、状态读取 sync_status.py 和同步页 sync.js。保留账号、X登录、原帖payload、已刷新媒体、启用时间、私有库和发送历史，不改变公告和对话工具。

Telegram editMessageMedia 支持把纯文字消息替换为带媒体的消息。该功能编辑同一个 message_id，原位置和链接保留，使用保存的原始正文作为caption，并保留 View on X 按钮。动画使用 InputMediaAnimation；普通MP4使用 InputMediaVideo。

接口参考：https://core.telegram.org/bots/api#editmessagemedia
客户端生成文档：https://github.com/aiogram/aiogram/blob/dev-3.x/aiogram/methods/edit_message_media.py

## 可用条件

- 原帖已完成发送，原计划只有一条纯文字消息，且数据库保存了该机器人发送成功的有效 message_id。
- 只有一个待补GIF／视频，尚未尝试补发该段。已单独补发成功的媒体不会再次合并或删除。
- 原始全文不超过1024个UTF-16单位，完整保留，不截断。多个媒体、长文、原本已含照片等情况继续使用单独补媒体。

原消息若已经人工修改，需在确认前核对；程序只能使用私有库保存的原始正文，无法获取任意TG消息的最新文本。Telegram最终决定消息是否允许编辑。不会删除旧消息。

## 操作

sudo python3 deploy/install_sync_attach.py

成功标记：Media edit installed.

刷新：https://panel.chloehub.top/?v=sync-attach#sync

搜索帖子ID，点击“补到原消息”并核对确认。此前已经用 refresh-media 刷新过的媒体仍在库中，无需再次抓取。尚未刷新的旧帖可继续使用：

sudo python3 /opt/coinw-x-forward/x_to_telegram.py refresh-media --post-id 2120844052983857396

## 失败及重试

- 请求和其他人工操作共用登录、CSRF、sync.manage、修订值校验、私有队列及工作锁。客户端不提供媒体URL、message_id、正文、频道或Token。
- 编辑前记录sending，并持久保存原消息ID和“编辑原消息”操作。重启/429/明确重试继续编辑同一条消息，不改为新发送。
- 超时/无效回执/进程中断保留uncertain，需要核对原消息；未核对前不会改为单独发送。确认已补上可标记收到。
- 明确拒绝时保留原消息和错误记录，可重试编辑。也可明确确认“改为单独补发”，只发送媒体，不重发原文。
- Telegram明确返回“message is not modified”时，视为该次编辑的目标状态已存在，仅适用于editMessageMedia。
- 完整重新发布会归档旧记录并清除该帖编辑操作标记，重新发布的内容不会回头编辑旧消息。

安装前备份代码和数据库，健康检查失败回滚代码，不清空已有媒体缓存。发布的安装包不含凭据。验证为本地模拟Telegram及真实浏览器；没有使用真实频道验证编辑权限和播放效果。
