#!/usr/bin/env python3
"""Personal Telegram account login + disclosed dialogue worker. Credentials stay on host."""
import argparse
import asyncio
import fcntl
import getpass
import json
import os
from pathlib import Path
import sys
import time
import warnings

from dialogue import Dialogues


class DeliveryError(Exception):
    def __init__(self,kind,wait=0):
        self.kind,self.wait=kind,wait


def hidden(prompt):
    with warnings.catch_warnings():
        warnings.simplefilter('error',getpass.GetPassWarning)
        return getpass.getpass(prompt).strip()


def credentials(home):
    path=home/'api.json'
    info=path.lstat()
    if path.is_symlink() or info.st_mode&0o077:raise ValueError('API配置文件须为私有普通文件（600）')
    data=json.loads(path.read_text())
    return int(data['api_id']),data['api_hash']


async def login(service,account_id):
    from telethon import TelegramClient, errors
    if not sys.stdin.isatty():raise ValueError('请在服务器交互式终端登录，不接受聊天或管道凭据')
    with service.db() as db:
        if not db.execute('SELECT 1 FROM accounts WHERE id=?',(account_id,)).fetchone():raise ValueError('请先在后台创建账号标签')
    if not (service.home/'api.json').exists():
        api_id=int(input('Telegram API ID（从你自己的 my.telegram.org 获取）: ').strip())
        api_hash=hidden('Telegram API Hash（隐藏输入）: ')
        import re
        if api_id<=0 or not re.fullmatch(r'[a-fA-F0-9]{32}',api_hash):raise ValueError('API配置格式无效')
        fd=os.open(service.home/'api.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as output:json.dump({'api_id':api_id,'api_hash':api_hash},output)
    api_id,api_hash=credentials(service.home)
    client=TelegramClient(str(service.home/f'account-{account_id}'),api_id,api_hash)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            phone=hidden('Telegram 手机号（隐藏输入）: ')
            await client.send_code_request(phone)
            code=hidden('Telegram 登录验证码（隐藏输入）: ')
            try:await client.sign_in(phone,code)
            except errors.SessionPasswordNeededError:
                await client.sign_in(password=hidden('Telegram 二步验证密码（隐藏输入）: '))
        me=await client.get_me()
        if getattr(me,'bot',False):raise ValueError('此工具用于你自己的个人运营账号')
        with service.db() as db:
            # One physical account must share a single rate limit and daily cap.
            if db.execute('SELECT 1 FROM accounts WHERE telegram_id=? AND id!=?',(me.id,account_id)).fetchone():raise ValueError('这个Telegram账号已绑定其他标签，请勿重复绑定')
            db.execute('UPDATE accounts SET connected=1,telegram_id=?,username=? WHERE id=?',(me.id,me.username or '',account_id))
            service.audit(db,'server','login',str(account_id))
        print('账号登录成功；后台可查看连接状态。未发送群消息。')
    finally:
        await client.disconnect()
        for path in service.home.glob(f'account-{account_id}.session*'):path.chmod(0o600)


class TelegramSender:
    def __init__(self,service):
        self.service=service;self.clients={};self.next_connect={}

    async def watch(self):
        """Connect authorized operators before schedules start so human activity can pause them."""
        from telethon import errors
        now=time.time()
        with self.service.db() as db:
            accounts=db.execute('SELECT id FROM accounts WHERE enabled=1 AND connected=1 AND blocked_until<=?',(now,)).fetchall()
        for row in accounts:
            aid=row['id']
            if aid in self.clients or now<self.next_connect.get(aid,0):continue
            self.next_connect[aid]=now+120
            try:await asyncio.wait_for(self.client(aid),timeout=15)
            except errors.FloodWaitError as error:
                self.service.account_problem(aid,'flood_wait',max(1,error.seconds))
                self.next_connect[aid]=now+max(120,error.seconds)
            except (errors.AuthKeyUnregisteredError,errors.SessionRevokedError,errors.UserDeactivatedError):
                self.service.account_problem(aid,'session_invalid')
            except DeliveryError as error:
                self.service.account_problem(aid,error.kind,error.wait)
            except Exception:
                # A failed connection is not proof of a revoked login. The send path classifies it.
                with self.service.db() as db:self.service.audit(db,'worker','listener_wait',str(aid))
            break

    async def client(self,aid):
        from telethon import TelegramClient, events, errors
        if aid in self.clients:return self.clients[aid]
        api_id,api_hash=credentials(self.service.home)
        client=TelegramClient(str(self.service.home/f'account-{aid}'),api_id,api_hash,request_retries=0,connection_retries=0,flood_sleep_threshold=0)
        try:
            await client.connect()
            if not await client.is_user_authorized():raise DeliveryError('session_invalid')
            me=await client.get_me()
            with self.service.db() as db:
                row=db.execute('SELECT telegram_id FROM accounts WHERE id=?',(aid,)).fetchone()
            if not row or row['telegram_id']!=me.id:raise DeliveryError('session_invalid')
            @client.on(events.NewMessage(incoming=True))
            async def incoming(event):
                if event.is_group and event.chat_id and event.sender_id:
                    self.service.human_message(event.chat_id,event.sender_id)
            # Resolve only groups this authorized account already belongs to.
            await client.get_dialogs(limit=200)
            self.clients[aid]=client
            return client
        except BaseException:
            await client.disconnect();raise

    async def send(self,job):
        from telethon import errors, utils
        started=False
        try:
            client=await self.client(job['account_id'])
            entity=await client.get_entity(job['group_id'])
            if getattr(entity,'broadcast',False) or not (getattr(entity,'megagroup',False) or entity.__class__.__name__=='Chat'):
                raise DeliveryError('not_a_group')
            if utils.get_peer_id(entity)!=job['group_id']:raise DeliveryError('wrong_group')
            if not self.service.still_allowed(job):raise DeliveryError('cancelled')
            started=True
            message=await client.send_message(entity,job['text'],reply_to=job['reply_message_id'],parse_mode=None,link_preview=False)
            return message.id
        except errors.SlowModeWaitError as error:
            raise DeliveryError('slow_mode',max(1,error.seconds)) from None
        except errors.FloodWaitError as error:
            raise DeliveryError('flood_wait',max(1,error.seconds)) from None
        except (errors.AuthKeyUnregisteredError,errors.SessionRevokedError,errors.UserDeactivatedError):
            raise DeliveryError('session_invalid') from None
        except errors.UserBannedInChannelError:
            raise DeliveryError('user_banned') from None
        except errors.ChatAdminRequiredError:
            raise DeliveryError('admin_required') from None
        except errors.ChatSendPlainForbiddenError:
            raise DeliveryError('text_forbidden') from None
        except (errors.ChatWriteForbiddenError,errors.ChatRestrictedError):
            raise DeliveryError('write_forbidden') from None
        except errors.RPCError as error:
            if error.message=='TOPIC_CLOSED':raise DeliveryError('topic_closed') from None
            raise DeliveryError('uncertain' if started else 'client_error') from None
        except (OSError,TimeoutError,ValueError):
            raise DeliveryError('uncertain' if started else 'connection_failed') from None

    async def close(self):
        for client in self.clients.values():await client.disconnect()


async def tick(service,sender,now=None):
    now=time.time() if now is None else now
    service.heartbeat(now);service.materialize(now)
    job=service.claim(now)
    if not job:return False
    try:
        mid=await asyncio.wait_for(sender.send(job),timeout=45)
        if not isinstance(mid,int) or mid<=0:raise DeliveryError('uncertain')
        service.finish(job,'sent',mid)
    except DeliveryError as error:
        status='cancelled' if error.kind=='cancelled' else 'uncertain' if error.kind=='uncertain' else 'failed'
        service.finish(job,status,detail=error.kind,wait=error.wait)
    except TimeoutError:
        service.finish(job,'uncertain',detail='timeout')
    except Exception:
        service.finish(job,'uncertain',detail='unexpected_client_error')
    return True


async def run(service):
    service.recover();sender=TelegramSender(service)
    try:
        while True:
            await sender.watch()
            worked=await tick(service,sender)
            await asyncio.sleep(0.5 if worked else 2)
    finally:await sender.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('run','login'))
    parser.add_argument('--home',default='/var/lib/coinw/dialogue')
    parser.add_argument('--account',type=int)
    args=parser.parse_args();os.umask(0o077)
    service=Dialogues(args.home)
    with (service.home/'worker.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise ValueError('请先停止运营互动服务，再执行登录；不能重复启动工作进程') from None
        if args.action=='login':
            if not args.account or args.account<1:raise ValueError('请指定后台账号标签ID')
            asyncio.run(login(service,args.account))
        else:
            credentials(service.home)
            asyncio.run(run(service))


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('已停止。')
    except Exception:
        print('操作未完成：请检查依赖、私有API配置和账号登录状态。未输出凭据或原始Telegram错误。',file=sys.stderr)
        sys.exit(1)
