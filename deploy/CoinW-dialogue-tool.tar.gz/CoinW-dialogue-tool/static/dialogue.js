/* Account/session credentials are configured only in the host terminal. */
(() => {
pages.dialogue=['社群互动排期','选择运营账号，编排话题、引用回复和每日发送时间。'];
const nav=document.createElement('button');nav.className='nav-item';nav.dataset.page='dialogue';nav.innerHTML='<span>☷</span> 社群互动排期';document.querySelector('nav').append(nav);
let state=null,draft=null,fetching=false,editMode='bulk',bulkText='',bulkStart='',bulkInterval='120';
const canManage=()=>accessAllowed(currentUser,'dialogue.manage');
const future=()=>new Date(Date.now()+28800000+300000).toISOString();
const fresh=()=>({title:'',group_id:state?.groups.find(g=>g.enabled)?.id||'',mode:'once',start_date:future().slice(0,10),end_date:future().slice(0,10),pause_on_human:true,show_marker:true,steps:[{account_id:state?.accounts[0]?.id||'',time:future().slice(11,19),text:'',reply_to:null}]});
const statuses={draft:'草稿',active:'已启用',paused:'已暂停',cancelled:'已取消',pending:'待发送',sending:'发送中',sent:'已发送',uncertain:'待核对',failed:'失败',missed:'错过时段',skipped:'启用前时段已跳过'};
const reasons={timeout:'发送超时，需先核对群消息',worker_interrupted:'工作进程中断，需先核对群消息',flood_wait:'Telegram 限流，账号等待中',slow_mode:'群慢速模式等待中',session_invalid:'登录已失效，请在服务器重新登录',write_forbidden:'账号无群发言权限：请用该账号到目标群手动发言，检查是否入群或被禁言',user_banned:'账号被目标群限制，请联系群管理员核实',admin_required:'目标操作需要群管理权限，请检查群设置',topic_closed:'目标话题已关闭，请由群管理员核实',text_forbidden:'目标群不允许此账号发送文本',connection_failed:'连接失败，计划已暂停',uncertain:'结果不确定，请核对群消息',daily_cap:'账号已达每日上限',missed_window:'错过发送窗口，未补发',reply_target_missing:'引用目标未成功发送',group_disabled:'群白名单已停用',account_unavailable:'账号未登录或未启用',unexpected_client_error:'客户端异常，需核对',manually_confirmed:'管理员已核对'};
const clock=t=>t?date(t*1000):'暂无记录';
function options(rows,value){return rows.map(r=>`<option value="${r.id}" ${String(value)===String(r.id)?'selected':''}>${esc(r.alias||r.title)} · ${r.id}</option>`).join('');}
function capture(f){
 if(!draft)return;
 for(const name of ['title','group_id','mode','start_date','end_date'])draft[name]=f.elements[name].value;
 draft.pause_on_human=f.elements.pause_on_human.checked;draft.show_marker=f.elements.show_marker.checked;
 if(editMode==='bulk'){bulkText=f.elements.script.value;bulkStart=f.elements.bulk_start.value;bulkInterval=f.elements.bulk_interval.value;}
 else draft.steps=[...f.querySelectorAll('[data-dialogue-row]')].map(row=>({account_id:Number(row.querySelector('[data-field=account_id]').value),time:row.querySelector('[data-field=time]').value,text:row.querySelector('[data-field=text]').value,reply_to:row.querySelector('[data-field=reply_to]').value?Number(row.querySelector('[data-field=reply_to]').value):null}));
}
function formatScript(steps){return steps.map(s=>{const alias=state.accounts.find(a=>a.id===s.account_id)?.alias;const name=alias&&!/[|｜\r\n]/.test(alias)&&state.accounts.filter(a=>a.alias.normalize('NFKC').replace(/\s/g,'').toLowerCase()===alias.normalize('NFKC').replace(/\s/g,'').toLowerCase()).length===1?alias:'#'+s.account_id;return `${name} | ${s.reply_to?'回复'+s.reply_to:'不引用'} | ${s.time}：\n${s.text}`;}).join('\n\n');}
function resetEditor(value){draft=value||fresh();editMode='bulk';bulkStart=draft.steps[0]?.time||future().slice(11,19);bulkInterval='120';bulkText=draft.steps.some(s=>s.text)?formatScript(draft.steps):'';}
async function parseBulk(overrideTimes=false){const result=await api('/api/dialogue/scripts/parse',{script:bulkText,start_time:bulkStart,interval_seconds:bulkInterval,override_times:overrideTimes,show_marker:draft.show_marker});draft.steps=result.steps;return result;}
function preview(){ $('#dialogue-preview-result').innerHTML=draft.steps.map((s,i)=>`<div class="dialogue-preview"><b>${i+1}. ${esc(state.accounts.find(a=>a.id===s.account_id)?.alias||'未选择账号')} · ${esc(s.time)}</b>${s.reply_to?`<small>引用第 ${s.reply_to} 条：${esc(draft.steps[s.reply_to-1]?.text||'')}</small>`:''}<p>${esc((draft.show_marker?'[运营互动] ':'')+s.text)}</p></div>`).join(''); }
function editor(){
 const d=draft;
 const bulk=`<div class="form-grid"><label>统一开始时间（北京时间）<input name="bulk_start" type="time" step="1" required value="${esc(bulkStart)}"></label><label>每条间隔（秒）<input name="bulk_interval" type="number" min="5" max="86400" required value="${esc(bulkInterval)}"></label></div><p class="form-hint">整段粘贴即可。每条以“后台账号标签 | 不引用：”或“后台账号标签 | 回复1：”单独一行开头，正文写在下面，可换行。回复1表示引用本脚本第1条。可用 #账号ID 替代标签。</p><label>整段对话脚本<textarea name="script" rows="16" maxlength="400000" required placeholder="运营A | 不引用：&#10;Following today's ETF poll, what matters most to you?&#10;&#10;运营B | 回复1：&#10;I'd focus on several days of data.">${esc(bulkText)}</textarea></label><p class="form-hint">默认按统一开始时间和间隔排期。需要逐条指定时间时，标题写作“运营A | 不引用 | 18:30:00：”；标题中的时间优先生效。改过统一开始时间后，可点击下面按钮覆盖全部标题时间；日期需在上方调整。预览不会发送。</p><button class="button" type="button" id="dialogue-retime">按统一时间重新排期</button>`;
 const rows=`<div id="dialogue-rows">${d.steps.map((step,index)=>`<section class="dialogue-row" data-dialogue-row><h3>第 ${index+1} 条</h3><div class="form-grid"><label>发言账号<select data-field="account_id" required><option value="">选择运营账号</option>${options(state.accounts,step.account_id)}</select></label><label>发送时间<input data-field="time" type="time" step="1" required value="${esc(step.time)}"></label><label>引用回复<select data-field="reply_to"><option value="">不引用</option>${d.steps.slice(0,index).map((_,i)=>`<option value="${i+1}" ${step.reply_to===i+1?'selected':''}>回复第 ${i+1} 条</option>`).join('')}</select></label></div><label>消息文案<textarea data-field="text" rows="3" maxlength="3500" required>${esc(step.text)}</textarea></label><button class="text-button" type="button" data-remove-dialogue="${index}">删除此条</button></section>`).join('')}</div>`;
 return panel('编排对话脚本','可整段粘贴或逐条编辑，支持选择是否显示消息标记；时间均为北京时间。',`<form id="dialogue-plan-form" class="dialogue-edit"><div class="form-grid"><label>计划名称<input name="title" required maxlength="80" value="${esc(d.title)}"></label><label>目标群<select name="group_id" required><option value="">选择白名单群</option>${options(state.groups.filter(g=>g.enabled),d.group_id)}</select></label><label>执行方式<select name="mode"><option value="daily" ${d.mode==='daily'?'selected':''}>每天按脚本执行</option><option value="once" ${d.mode==='once'?'selected':''}>指定日期一次</option></select></label><label>开始日期<input type="date" name="start_date" required value="${esc(d.start_date)}"></label><label>结束日期<input type="date" name="end_date" required value="${esc(d.end_date)}"></label></div><label class="ann-check"><input type="checkbox" name="pause_on_human" ${d.pause_on_human?'checked':''}> 非运营账号成员参与时暂停，交给管理员接续</label><label class="ann-check"><input type="checkbox" name="show_marker" ${d.show_marker!==false?'checked':''}> 消息开头显示 [运营互动]（取消勾选可去掉；账号昵称、简介或群公告应说明运营自动互动身份）</label><div class="toolbar"><button class="button" type="button" id="dialogue-mode">${editMode==='bulk'?'切换逐条编辑':'切换整段粘贴'}</button><button class="button" type="button" id="dialogue-example">填入两条示例</button></div>${editMode==='bulk'?bulk:rows}<div class="toolbar">${editMode==='rows'?'<button class="button" type="button" id="dialogue-add-row">＋ 添加消息</button>':''}<button class="button" type="button" id="dialogue-preview">解析并预览</button><button class="button" type="submit">保存草稿</button><button class="primary" type="submit" value="start">保存并启用</button><button class="text-button" type="button" id="dialogue-new">新建计划</button></div><p class="form-hint">保存草稿不会发送。“保存并启用”需确认后执行。修改前请暂停，失败后先修复原因并重新设置未来时间。账号频率和每日上限仍生效，过期消息不集中补发。</p><div id="dialogue-preview-result" aria-live="polite"></div></form>`);
}
function screen(){
 if(!state)return empty('正在读取互动排期…');
 if(!draft)resetEditor();
 const alive=state.worker_heartbeat&&state.server_time-state.worker_heartbeat<120;
 let html=panel(alive?'工作进程在线':'工作进程尚未运行或连接已中断','最近心跳：'+clock(state.worker_heartbeat),`<p class="sync-notice">${alive?'只会执行已启用的计划。':'请先在服务器完成账号登录及工作进程安装；草稿不会发送。'} 暂停会停止后续消息，已在发送中的请求仍可能送达。</p>`);
 html+=panel('运营账号','需要几个账号就创建几个标签，再在服务器逐个登录。账号应明确标注运营／自动互动身份。',table(['账号','连接状态','最短间隔 / 每日上限','等待至','操作'],state.accounts.map(a=>`<tr><td>${esc(a.alias)}<small>ID ${a.id}${a.username?' · @'+esc(a.username):''}</small></td><td>${a.connected?'已登录':'未登录'} · ${a.enabled?'已启用':'已停用'}</td><td>${a.min_interval} 秒 / ${a.daily_cap} 条</td><td>${a.blocked_until>state.server_time?clock(a.blocked_until):'无'}</td><td>${canManage()?`<button class="text-button" data-dialogue-account="${a.id}">修改频率与启用状态</button>`:'—'}</td></tr>`)))+
 (canManage()?panel('账号设置','这里只保存标签与发送额度，手机号、验证码、密码及会话不通过网页提交。',`<form id="dialogue-account-form" class="dialogue-edit"><input type="hidden" name="id"><div class="form-grid"><label>账号标签<input name="alias" required maxlength="80" placeholder="例如：运营主持 A"></label><label>最短间隔（秒）<input name="min_interval" type="number" min="5" max="86400" value="60" required></label><label>每日上限（北京时间）<input name="daily_cap" type="number" min="1" max="500" value="30" required></label></div><label class="ann-check"><input type="checkbox" name="enabled"> 启用此账号</label><button class="button" type="submit">保存账号设置</button></form>`):'');
 html+=panel('群白名单','只支持你管理且允许自动互动的群；不会加群、私聊或联系群成员。',table(['群名称','群 ID','状态'],state.groups.map(g=>`<tr><td>${esc(g.title)}</td><td>${g.id}</td><td>${g.enabled?'启用':'停用'}</td></tr>`))+(canManage()?`<form id="dialogue-group-form" class="dialogue-edit"><div class="form-grid"><label>群名称<input name="title" required maxlength="80"></label><label>群 ID<input name="id" type="text" inputmode="numeric" placeholder="-100…" required pattern="-[0-9]+"></label></div><label class="ann-check"><input name="owned" type="checkbox" required> 我管理此群，且已向成员说明运营自动互动用途</label><label class="ann-check"><input name="enabled" type="checkbox" checked> 启用白名单（取消勾选后保存可停用）</label><button class="button" type="submit">保存群白名单</button></form>`:''));
 if(canManage())html+=editor();
 html+=panel('计划列表','启用前请确认账号、群、日期和脚本预览。',table(['计划 / 群','日期与重复','状态','操作'],state.plans.map(p=>`<tr><td>${esc(p.title)}<small>群 ${p.group_id} · ${p.steps.length} 条消息</small></td><td>${esc(p.start_date)} 至 ${esc(p.end_date)}<small>${p.mode==='daily'?'每天':'一次'}</small></td><td>${esc(statuses[p.status]||p.status)}</td><td>${canManage()?`<button class="text-button" data-edit-dialogue="${p.id}">编辑</button>${p.status!=='cancelled'?`<button class="text-button" data-control-dialogue="${p.id}" data-action="${p.status==='active'?'pause':'start'}">${p.status==='active'?'暂停':'启用'}</button><button class="text-button negative" data-control-dialogue="${p.id}" data-action="cancel">取消</button>`:''}`:'—'}</td></tr>`)));
 html+=panel('发送记录','最近200条，发送结果不确定时先核对群消息，系统不会自动重发。',table(['日期 / 时间','计划 / 序号','账号 / 文案','状态','处理'],state.jobs.map(j=>`<tr><td>${esc(j.day)}<small>${clock(j.due)}</small>${j.sent_at?`<small>实际发送 ${clock(j.sent_at)}</small>`:''}</td><td>${j.plan_id} / 第 ${j.seq} 条</td><td>${esc(state.accounts.find(a=>a.id===j.account_id)?.alias||j.account_id)}<small class="sync-excerpt">${esc(j.text)}</small></td><td>${esc(statuses[j.status]||j.status)}<small>${esc(reasons[j.detail]||j.detail)}</small>${j.message_id?`<small>消息 ID ${j.message_id}</small>`:''}</td><td>${canManage()&&j.status==='uncertain'?`<button class="text-button" data-resolve-dialogue="${j.id}" data-action="received">已收到</button><button class="text-button" data-resolve-dialogue="${j.id}" data-action="not_received">未收到，取消此条</button>`:'—'}</td></tr>`)));
 html+=panel('操作日志','最近100条，记录操作人与执行异常。',table(['时间','操作人','操作','记录'],state.audit.map(a=>`<tr><td>${clock(a.created)}</td><td>${esc(a.actor)}</td><td>${esc(a.action)}</td><td>${esc(a.detail)}</td></tr>`)));
 return html;
}
function paint(){if(page==='dialogue'&&csrf&&accessAllowed(currentUser,'dialogue.view')&&$('#dialogue-screen'))$('#dialogue-screen').innerHTML=screen();}
async function load(){if(fetching)return;fetching=true;const session=csrf;try{const result=await api('/api/dialogue/status');if(csrf===session){state=result;paint();}}catch(error){if(page==='dialogue'&&$('#dialogue-screen'))$('#dialogue-screen').innerHTML=empty(error.message);}finally{fetching=false;}}
const previous=render;
render=function(){previous();if(page==='dialogue'){$('.context-bar').hidden=true;$('#manage-disconnected').hidden=true;$('#content').innerHTML='<div id="dialogue-screen"></div>';paint();load();}};
function changed(e){if(e.target.closest('#dialogue-plan-form')){capture($('#dialogue-plan-form'));$('#dialogue-preview-result').textContent='内容已修改，请重新解析预览。';}}
document.addEventListener('input',changed);
document.addEventListener('change',changed);
document.addEventListener('submit',async e=>{
 if(!['dialogue-plan-form','dialogue-account-form','dialogue-group-form'].includes(e.target.getAttribute('id')))return;
 e.preventDefault();const f=e.target,fid=f.getAttribute('id'),button=e.submitter;button.disabled=true;
 try{
  if(fid==='dialogue-plan-form'){
   capture(f);if(editMode==='bulk')await parseBulk();preview();
   const start=button.value==='start';
   if(start&&!confirm(`确认保存并启用“${draft.title}”？共 ${draft.steps.length} 条消息，将按预览的北京时间向群 ${draft.group_id} 发送，${draft.show_marker?'正文带 [运营互动] 标记':'正文不添加 [运营互动] 前缀'}。请先确认这些账号可在该群正常发言。`))return;
   const saved=await api('/api/dialogue/plans/save',draft);draft.id=saved.id;
   if(start){try{await api('/api/dialogue/plans/control',{id:saved.id,action:'start'});}catch(error){await load();throw new Error('草稿已保存，未启用：'+error.message);}}
   toast(start?'已保存并启用，请查看计划状态及发送记录':'草稿已保存，尚未启用');
  }
  if(fid==='dialogue-account-form'){await api('/api/dialogue/accounts',{id:f.elements.id.value||null,alias:f.elements.alias.value,min_interval:f.elements.min_interval.value,daily_cap:f.elements.daily_cap.value,enabled:f.elements.enabled.checked});toast('账号配置已保存，登录请在服务器完成');}
  if(fid==='dialogue-group-form'){await api('/api/dialogue/groups',{id:f.elements.id.value,title:f.elements.title.value,owned:f.elements.owned.checked,enabled:f.elements.enabled.checked});toast('群白名单已保存');}
  await load();
 }catch(error){toast(error.message);}finally{button.disabled=false;}
});
document.addEventListener('click',async e=>{
 const b=e.target.closest('button');if(!b||page!=='dialogue'||!canManage())return;
 if(b.id==='dialogue-add-row'){capture($('#dialogue-plan-form'));if(draft.steps.length>=100){toast('每个脚本最多100条');return;}draft.steps.push({account_id:state.accounts[0]?.id||'',time:draft.steps.at(-1)?.time||'16:00:00',text:'',reply_to:null});paint();}
 if(b.dataset.removeDialogue!==undefined){capture($('#dialogue-plan-form'));const removed=Number(b.dataset.removeDialogue)+1;draft.steps.splice(removed-1,1);draft.steps.forEach(s=>{if(s.reply_to===removed)s.reply_to=null;else if(s.reply_to>removed)s.reply_to--;});paint();}
 if(b.id==='dialogue-new'){resetEditor();paint();}
 if(b.dataset.editDialogue){const p=state.plans.find(p=>p.id===Number(b.dataset.editDialogue));if(p.status==='active'){toast('请先暂停计划再编辑');return;}resetEditor(JSON.parse(JSON.stringify(p)));paint();$('#dialogue-plan-form').scrollIntoView({block:'start'});}
 if(b.dataset.dialogueAccount){const a=state.accounts.find(a=>a.id===Number(b.dataset.dialogueAccount)),f=$('#dialogue-account-form');for(const k of ['id','alias','min_interval','daily_cap'])f.elements[k].value=a[k];f.elements.enabled.checked=!!a.enabled;f.scrollIntoView({block:'center'});}
 if(b.id==='dialogue-example'){
  capture($('#dialogue-plan-form'));
  if(!state.accounts.length){toast('请先创建运营账号标签');return;}
  if((editMode==='bulk'?bulkText.trim():draft.steps.some(s=>s.text))&&!confirm('用两条示例替换编辑框内容？已保存的计划不会改变。'))return;
  editMode='bulk';bulkText=`#${state.accounts[0].id} | 不引用：\nFollowing today's ETF poll, what matters most to you: fund flows, macro news, or price action?\n\n#${state.accounts[1]?.id||state.accounts[0].id} | 回复1：\nI'd focus on several days of data rather than a single day's inflow.`;paint();
 }
 if(b.id==='dialogue-retime'){
  capture($('#dialogue-plan-form'));b.disabled=true;
  try{await parseBulk(true);bulkText=formatScript(draft.steps);paint();preview();toast('已按统一时间重排，尚未保存或启用');}catch(error){toast(error.message);}finally{b.disabled=false;}
 }
 if(b.id==='dialogue-preview'||b.id==='dialogue-mode'){
  capture($('#dialogue-plan-form'));b.disabled=true;
  try{if(editMode==='bulk'&&bulkText.trim())await parseBulk();else if(editMode==='bulk'&&b.id==='dialogue-preview')throw new Error('请先粘贴脚本');
   if(b.id==='dialogue-mode'){if(editMode==='rows'){bulkText=formatScript(draft.steps);bulkStart=draft.steps[0]?.time||bulkStart;}editMode=editMode==='bulk'?'rows':'bulk';paint();}
   else preview();
  }catch(error){toast(error.message);}finally{b.disabled=false;}
 }
 if(b.dataset.controlDialogue){if(!confirm(b.dataset.action==='start'?'确认启用此计划？将按保存的文案及标记设置向白名单群发送，过去时段将跳过。':'确认暂停或取消？已在发送中的请求可能仍会送达。'))return;b.disabled=true;try{await api('/api/dialogue/plans/control',{id:b.dataset.controlDialogue,action:b.dataset.action});await load();toast('计划状态已更新');}catch(error){toast(error.message);}finally{b.disabled=false;}}
 if(b.dataset.resolveDialogue){const received=b.dataset.action==='received';let mid=null;if(received){mid=prompt('请核对群中已收到的消息，填写该群消息ID（消息链接最后一段数字）');if(!mid)return;}if(!confirm(received?'确认该消息确实已收到？不会自动重发。':'确认未收到？此条将取消，计划保持暂停；需要时另行编辑排期。'))return;try{await api('/api/dialogue/jobs/resolve',{id:b.dataset.resolveDialogue,action:b.dataset.action,confirmed:true,message_id:mid});await load();}catch(error){toast(error.message);}}
});
const oldLogout=window.onAccessLogout;window.onAccessLogout=()=>{state=null;draft=null;bulkText='';oldLogout?.();};
})();
