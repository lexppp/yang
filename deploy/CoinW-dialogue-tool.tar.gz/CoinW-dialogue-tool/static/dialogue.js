/* Account/session credentials are configured only in the host terminal. */
(() => {
pages.dialogue=['社群互动排期','选择运营账号，编排话题、引用回复和每日发送时间。'];
const nav=document.createElement('button');nav.className='nav-item';nav.dataset.page='dialogue';nav.innerHTML='<span>☷</span> 社群互动排期';document.querySelector('nav').append(nav);
let state=null,draft=null,fetching=false;
const canManage=()=>accessAllowed(currentUser,'dialogue.manage');
const day=()=>new Date(Date.now()+28800000).toISOString().slice(0,10);
const fresh=()=>({title:'',group_id:state?.groups.find(g=>g.enabled)?.id||'',mode:'daily',start_date:day(),end_date:day(),pause_on_human:true,steps:[{account_id:state?.accounts[0]?.id||'',time:'16:00:00',text:'',reply_to:null}]});
const statuses={draft:'草稿',active:'已启用',paused:'已暂停',cancelled:'已取消',pending:'待发送',sending:'发送中',sent:'已发送',uncertain:'待核对',failed:'失败',missed:'错过时段',skipped:'启用前时段已跳过'};
const reasons={timeout:'发送超时，需先核对群消息',worker_interrupted:'工作进程中断，需先核对群消息',flood_wait:'Telegram 限流，账号等待中',session_invalid:'登录已失效，请在服务器重新登录',write_forbidden:'账号无群发言权限',connection_failed:'连接失败，计划已暂停',uncertain:'结果不确定，请核对群消息',daily_cap:'账号已达每日上限',missed_window:'错过发送窗口，未补发',reply_target_missing:'引用目标未成功发送',group_disabled:'群白名单已停用',account_unavailable:'账号未登录或未启用',unexpected_client_error:'客户端异常，需核对',manually_confirmed:'管理员已核对'};
const clock=t=>t?date(t*1000):'暂无记录';
function options(rows,value){return rows.map(r=>`<option value="${r.id}" ${String(value)===String(r.id)?'selected':''}>${esc(r.alias||r.title)} · ${r.id}</option>`).join('');}
function capture(f){
 if(!draft)return;
 for(const name of ['title','group_id','mode','start_date','end_date'])draft[name]=f.elements[name].value;
 draft.pause_on_human=f.elements.pause_on_human.checked;
 draft.steps=[...f.querySelectorAll('[data-dialogue-row]')].map(row=>({account_id:Number(row.querySelector('[data-field=account_id]').value),time:row.querySelector('[data-field=time]').value,text:row.querySelector('[data-field=text]').value,reply_to:row.querySelector('[data-field=reply_to]').value?Number(row.querySelector('[data-field=reply_to]').value):null}));
}
function editor(){
 const d=draft;
 return panel('编排对话脚本',`共 ${d.steps.length} 条消息，需 ${new Set(d.steps.map(s=>s.account_id).filter(Boolean)).size} 个运营账号。时间均为北京时间，自动消息带 [运营互动] 标记。`,`<form id="dialogue-plan-form" class="dialogue-edit"><div class="form-grid"><label>计划名称<input name="title" required maxlength="80" value="${esc(d.title)}"></label><label>目标群<select name="group_id" required><option value="">选择白名单群</option>${options(state.groups.filter(g=>g.enabled),d.group_id)}</select></label><label>执行方式<select name="mode"><option value="daily" ${d.mode==='daily'?'selected':''}>每天按脚本执行</option><option value="once" ${d.mode==='once'?'selected':''}>指定日期一次</option></select></label><label>开始日期<input type="date" name="start_date" required value="${esc(d.start_date)}"></label><label>结束日期<input type="date" name="end_date" required value="${esc(d.end_date)}"></label></div><label class="ann-check"><input type="checkbox" name="pause_on_human" ${d.pause_on_human?'checked':''}> 非运营账号成员参与时暂停，交给管理员接续</label>
 <div id="dialogue-rows">${d.steps.map((step,index)=>`<section class="dialogue-row" data-dialogue-row><h3>第 ${index+1} 条</h3><div class="form-grid"><label>发言账号<select data-field="account_id" required><option value="">选择运营账号</option>${options(state.accounts,step.account_id)}</select></label><label>发送时间<input data-field="time" type="time" step="1" required value="${esc(step.time)}"></label><label>引用回复<select data-field="reply_to"><option value="">不引用</option>${d.steps.slice(0,index).map((_,i)=>`<option value="${i+1}" ${step.reply_to===i+1?'selected':''}>回复第 ${i+1} 条</option>`).join('')}</select></label></div><label>消息文案<textarea data-field="text" rows="3" maxlength="3500" required>${esc(step.text)}</textarea></label><button class="text-button" type="button" data-remove-dialogue="${index}">删除此条</button></section>`).join('')}</div><div class="toolbar"><button class="button" type="button" id="dialogue-add-row">＋ 添加消息</button><button class="button" type="button" id="dialogue-preview">预览对话</button><button class="primary" type="submit">保存草稿</button><button class="text-button" type="button" id="dialogue-new">新建计划</button></div><p class="form-hint">保存不会发送。消息按时间顺序排列；修改计划前请暂停。账号频率与每日上限独立生效，过期消息不集中补发。</p><div id="dialogue-preview-result"></div></form>`);
}
function screen(){
 if(!state)return empty('正在读取互动排期…');
 draft=draft||fresh();
 const alive=state.worker_heartbeat&&state.server_time-state.worker_heartbeat<120;
 let html=panel(alive?'工作进程在线':'工作进程尚未运行或连接已中断','最近心跳：'+clock(state.worker_heartbeat),`<p class="sync-notice">${alive?'只会执行已启用的计划。':'请先在服务器完成账号登录及工作进程安装；草稿不会发送。'} 暂停会停止后续消息，已在发送中的请求仍可能送达。</p>`);
 html+=panel('运营账号','需要几个账号就创建几个标签，再在服务器逐个登录。账号应明确标注运营／自动互动身份。',table(['账号','连接状态','最短间隔 / 每日上限','等待至','操作'],state.accounts.map(a=>`<tr><td>${esc(a.alias)}<small>ID ${a.id}${a.username?' · @'+esc(a.username):''}</small></td><td>${a.connected?'已登录':'未登录'} · ${a.enabled?'已启用':'已停用'}</td><td>${a.min_interval} 秒 / ${a.daily_cap} 条</td><td>${a.blocked_until>state.server_time?clock(a.blocked_until):'无'}</td><td>${canManage()?`<button class="text-button" data-dialogue-account="${a.id}">修改频率与启用状态</button>`:'—'}</td></tr>`)))+
 (canManage()?panel('账号设置','这里只保存标签与发送额度，手机号、验证码、密码及会话不通过网页提交。',`<form id="dialogue-account-form" class="dialogue-edit"><input type="hidden" name="id"><div class="form-grid"><label>账号标签<input name="alias" required maxlength="80" placeholder="例如：运营主持 A"></label><label>最短间隔（秒）<input name="min_interval" type="number" min="5" max="86400" value="60" required></label><label>每日上限（北京时间）<input name="daily_cap" type="number" min="1" max="500" value="30" required></label></div><label class="ann-check"><input type="checkbox" name="enabled"> 启用此账号</label><button class="button" type="submit">保存账号设置</button></form>`):'');
 html+=panel('群白名单','只支持你管理且允许自动互动的群；不会加群、私聊或联系群成员。',table(['群名称','群 ID','状态'],state.groups.map(g=>`<tr><td>${esc(g.title)}</td><td>${g.id}</td><td>${g.enabled?'启用':'停用'}</td></tr>`))+(canManage()?`<form id="dialogue-group-form" class="dialogue-edit"><div class="form-grid"><label>群名称<input name="title" required maxlength="80"></label><label>群 ID<input name="id" type="text" inputmode="numeric" placeholder="-100…" required pattern="-[0-9]+"></label></div><label class="ann-check"><input name="owned" type="checkbox" required> 我管理此群，且已向成员说明运营自动互动用途</label><label class="ann-check"><input name="enabled" type="checkbox" checked> 启用白名单（取消勾选后保存可停用）</label><button class="button" type="submit">保存群白名单</button></form>`:''));
 if(canManage())html+=editor();
 html+=panel('计划列表','启用前请确认账号、群、日期和脚本预览。',table(['计划 / 群','日期与重复','状态','操作'],state.plans.map(p=>`<tr><td>${esc(p.title)}<small>群 ${p.group_id} · ${p.steps.length} 条消息</small></td><td>${esc(p.start_date)} 至 ${esc(p.end_date)}<small>${p.mode==='daily'?'每天':'一次'}</small></td><td>${esc(statuses[p.status]||p.status)}</td><td>${canManage()?`<button class="text-button" data-edit-dialogue="${p.id}">编辑</button>${p.status!=='cancelled'?`<button class="text-button" data-control-dialogue="${p.id}" data-action="${p.status==='active'?'pause':'start'}">${p.status==='active'?'暂停':'启用'}</button><button class="text-button negative" data-control-dialogue="${p.id}" data-action="cancel">取消</button>`:''}`:'—'}</td></tr>`)));
 html+=panel('发送记录','最近200条，发送结果不确定时先核对群消息，系统不会自动重发。',table(['日期 / 时间','计划 / 序号','账号 / 文案','状态','处理'],state.jobs.map(j=>`<tr><td>${esc(j.day)}<small>${clock(j.due)}</small>${j.sent_at?`<small>实际发送 ${clock(j.sent_at)}</small>`:''}</td><td>${j.plan_id} / 第 ${j.seq} 条</td><td>${esc(state.accounts.find(a=>a.id===j.account_id)?.alias||j.account_id)}<small class="sync-excerpt">${esc(j.text)}</small></td><td>${esc(statuses[j.status]||j.status)}<small>${esc(reasons[j.detail]||j.detail)}</small>${j.message_id?`<small>消息 ID ${j.message_id}</small>`:''}</td><td>${canManage()&&j.status==='uncertain'?`<button class="text-button" data-resolve-dialogue="${j.id}" data-action="received">已收到</button><button class="text-button" data-resolve-dialogue="${j.id}" data-action="not_received">未收到，取消此条</button>`:'—'}</td></tr>`)));
 html+=panel('操作日志','最近100条，记录操作人与执行异常。',table(['时间','操作人','操作','记录'],state.audit.map(a=>`<tr><td>${clock(a.created)}</td><td>${esc(a.actor)}</td><td>${esc(a.action)}</td><td>${esc(a.detail)}</td></tr>`)));
 return html;
}
function paint(){if(page==='dialogue'&&csrf&&accessAllowed(currentUser,'dialogue.view')&&$('#dialogue-screen'))$('#dialogue-screen').innerHTML=screen();}
async function load(){if(fetching)return;fetching=true;const session=csrf;try{const result=await api('/api/dialogue/status');if(csrf===session){state=result;paint();}}catch(error){if(page==='dialogue'&&$('#dialogue-screen'))$('#dialogue-screen').innerHTML=empty(error.message);}finally{fetching=false;}}
const previous=render;
render=function(){previous();if(page==='dialogue'){$('.context-bar').hidden=true;$('#manage-disconnected').hidden=true;$('#content').innerHTML='<div id="dialogue-screen"></div>';paint();load();}};
document.addEventListener('input',e=>{if(e.target.closest('#dialogue-plan-form'))capture($('#dialogue-plan-form'));});
document.addEventListener('change',e=>{if(e.target.closest('#dialogue-plan-form'))capture($('#dialogue-plan-form'));});
document.addEventListener('submit',async e=>{
 if(!['dialogue-plan-form','dialogue-account-form','dialogue-group-form'].includes(e.target.getAttribute('id')))return;
 e.preventDefault();const f=e.target,fid=f.getAttribute('id'),button=e.submitter;button.disabled=true;
 try{
  if(fid==='dialogue-plan-form'){capture(f);const saved=await api('/api/dialogue/plans/save',draft);draft.id=saved.id;toast('草稿已保存，尚未启用');}
  if(fid==='dialogue-account-form'){await api('/api/dialogue/accounts',{id:f.elements.id.value||null,alias:f.elements.alias.value,min_interval:f.elements.min_interval.value,daily_cap:f.elements.daily_cap.value,enabled:f.elements.enabled.checked});toast('账号配置已保存，登录请在服务器完成');}
  if(fid==='dialogue-group-form'){await api('/api/dialogue/groups',{id:f.elements.id.value,title:f.elements.title.value,owned:f.elements.owned.checked,enabled:f.elements.enabled.checked});toast('群白名单已保存');}
  await load();
 }catch(error){toast(error.message);}finally{button.disabled=false;}
});
document.addEventListener('click',async e=>{
 const b=e.target.closest('button');if(!b||page!=='dialogue'||!canManage())return;
 if(b.id==='dialogue-add-row'){capture($('#dialogue-plan-form'));if(draft.steps.length>=100){toast('每个脚本最多100条');return;}draft.steps.push({account_id:state.accounts[0]?.id||'',time:draft.steps.at(-1)?.time||'16:00:00',text:'',reply_to:null});paint();}
 if(b.dataset.removeDialogue!==undefined){capture($('#dialogue-plan-form'));const removed=Number(b.dataset.removeDialogue)+1;draft.steps.splice(removed-1,1);draft.steps.forEach(s=>{if(s.reply_to===removed)s.reply_to=null;else if(s.reply_to>removed)s.reply_to--;});paint();}
 if(b.id==='dialogue-new'){draft=fresh();paint();}
 if(b.dataset.editDialogue){const p=state.plans.find(p=>p.id===Number(b.dataset.editDialogue));if(p.status==='active'){toast('请先暂停计划再编辑');return;}draft=JSON.parse(JSON.stringify(p));paint();$('#dialogue-plan-form').scrollIntoView({block:'start'});}
 if(b.dataset.dialogueAccount){const a=state.accounts.find(a=>a.id===Number(b.dataset.dialogueAccount)),f=$('#dialogue-account-form');for(const k of ['id','alias','min_interval','daily_cap'])f.elements[k].value=a[k];f.elements.enabled.checked=!!a.enabled;f.scrollIntoView({block:'center'});}
 if(b.id==='dialogue-preview'){capture($('#dialogue-plan-form'));$('#dialogue-preview-result').innerHTML=draft.steps.map((s,i)=>`<div class="dialogue-preview"><b>${i+1}. ${esc(state.accounts.find(a=>a.id===s.account_id)?.alias||'未选择账号')} · ${esc(s.time)}</b>${s.reply_to?`<small>引用第 ${s.reply_to} 条：${esc(draft.steps[s.reply_to-1]?.text||'')}</small>`:''}<p>${esc('[运营互动] '+s.text)}</p></div>`).join('');}
 if(b.dataset.controlDialogue){if(!confirm(b.dataset.action==='start'?'确认启用此计划？只会按配置向白名单群发送带运营互动标记的消息，过去时段将跳过。':'确认暂停或取消？已在发送中的请求可能仍会送达。'))return;b.disabled=true;try{await api('/api/dialogue/plans/control',{id:b.dataset.controlDialogue,action:b.dataset.action});await load();toast('计划状态已更新');}catch(error){toast(error.message);}finally{b.disabled=false;}}
 if(b.dataset.resolveDialogue){const received=b.dataset.action==='received';let mid=null;if(received){mid=prompt('请核对群中已收到的消息，填写该群消息ID（消息链接最后一段数字）');if(!mid)return;}if(!confirm(received?'确认该消息确实已收到？不会自动重发。':'确认未收到？此条将取消，计划保持暂停；需要时另行编辑排期。'))return;try{await api('/api/dialogue/jobs/resolve',{id:b.dataset.resolveDialogue,action:b.dataset.action,confirmed:true,message_id:mid});await load();}catch(error){toast(error.message);}}
});
const oldLogout=window.onAccessLogout;window.onAccessLogout=()=>{state=null;draft=null;oldLogout?.();};
})();
