/* X -> Telegram monitoring and authorized manual publishing. */
(() => {
pages.sync=['X → Telegram 同步','来源、运行情况与每条帖子的发送记录，在这里查看。'];
const nav=document.createElement('button');nav.className='nav-item';nav.dataset.page='sync';nav.innerHTML='<span>⇄</span> X → Telegram 同步';document.querySelector('nav').append(nav);
let latest=null,busy=false,query='',filter='all';
const pending=new Map(),selected=new Map();
let batchMode='publish';
const states={baseline:'启用前旧帖 · 不补发',pending:'等待发送',sent:'已发送',sending:'发送中',uncertain:'结果待核对',failed:'发送被拒绝',retry:'限流等待重试',unknown:'状态未知'};
const clock=value=>value?date(value*1000):'暂无记录';
function reason(code){
 if(!code)return '暂无错误';
 if(code.includes('uncertain')||code.startsWith('delivery_requires_inspection'))return '发送结果不确定，请对照 TG 频道核对。为避免重复，后续发送已暂停。';
 if(code.includes('rate_limited'))return 'Telegram 限流，等待允许的重试时间。';
 if(code.includes('rejected'))return 'Telegram 拒绝发送，请检查频道权限和图片可用性。需处理后恢复。';
 if(code.includes('rsshub')||code.includes('feed'))return '来源读取失败或没有有效帖子，系统会退避检查。请检查 RSSHub 和 X 登录态。';
 if(code==='bot_cannot_post')return '机器人缺少目标频道发帖权限。';
 if(code.includes('unexpected'))return '机器人身份或目标频道与配置不一致。';
 return '同步检查未完成，请在服务器查看该独立服务的日志。';
}
function outcome(p){
 const ds=p.deliveries.map(d=>d.status);
 return ['uncertain','failed','retry','sending'].find(s=>ds.includes(s))||p.status;
}
function actions(p){
 if(!accessAllowed(currentUser,'sync.manage')||!latest.manual_supported||!p.revision)return '';
 if(pending.has(p.id)||(latest.requests||[]).some(r=>r.post_id===p.id&&['queued','processing'].includes(r.status)))return '<small>请求已提交，等待处理…</small>';
 if(latest.next_send>latest.server_time)return '<small>限流等待中</small>';
 if(p.status==='sent')return latest.republish_supported?`<button class="button" data-sync-action="republish" data-sync-post="${p.id}">重新发布</button>`:'<small>已发送，不重复发布</small>';
 const uncertain=p.deliveries.some(d=>['uncertain','sending'].includes(d.status));
 return uncertain?`<button class="button" data-sync-action="publish" data-sync-post="${p.id}">核对未收到，重试</button><button class="text-button" data-sync-action="mark_sent" data-sync-post="${p.id}">已收到，标记并继续</button>`:`<button class="button" data-sync-action="publish" data-sync-post="${p.id}">${p.status==='baseline'?'人工发布':outcome(p)==='failed'?'重试发布':'立即发布'}</button>`;
}
function visiblePosts(){
 return (latest?.posts||[]).filter(p=>(filter==='all'||outcome(p)===filter)&&`${p.id} ${p.text}`.toLowerCase().includes(query.toLowerCase()));
}
function selectable(p){
 return accessAllowed(currentUser,'sync.manage')&&latest?.manual_supported&&p.revision&&!pending.has(p.id)&&
  !(latest.requests||[]).some(r=>r.post_id===p.id&&['queued','processing'].includes(r.status))&&
  !p.deliveries.some(d=>['sending','uncertain'].includes(d.status))&&(p.status!=='sent'||latest.republish_supported);
}
function selectionBar(){
 if(!accessAllowed(currentUser,'sync.manage')||!latest?.manual_supported)return '';
 const visible=visiblePosts(),hidden=[...selected.keys()].filter(id=>!visible.some(p=>p.id===id)).length;
 return `<div class="toolbar sync-selection"><button class="button" id="sync-select-visible">选择当前筛选结果（最多20条）</button><button class="text-button" id="sync-clear-selection">清空选择</button><span role="status">已选 ${selected.size} 条${hidden?` · 筛选外 ${hidden} 条`:''}</span><select id="sync-batch-mode" aria-label="人工同步方式"><option value="publish" ${batchMode==='publish'?'selected':''}>补发未完成（跳过已发）</option>${latest.republish_supported?`<option value="republish" ${batchMode==='republish'?'selected':''}>重新发布已完成（新增消息）</option>`:''}</select><button class="primary" id="sync-publish-selected" ${!selected.size||latest.next_send>latest.server_time?'disabled':''}>同步所选</button></div><p class="form-hint">每次最多20条，使用已抓取的正文与图片。结果不确定的帖子请逐条核对处理；重新发布会在频道新增消息。</p>`;
}
function updateRecords(){
 if($('#sync-records'))$('#sync-records').innerHTML=records();
 if($('#sync-selection'))$('#sync-selection').innerHTML=selectionBar();
}
function records(){
 if(!latest?.available)return '';
 const list=visiblePosts();
 const choose=accessAllowed(currentUser,'sync.manage')&&latest.manual_supported;
 const rows=list.map(p=>`<tr>${choose?`<td>${selectable(p)?`<input type="checkbox" data-sync-select="${p.id}" aria-label="选择帖子 ${p.id}" ${selected.has(p.id)?'checked':''}>`:'—'}</td>`:''}<td>${clock(p.published)}<small>${esc(p.id)}</small></td><td><div class="sync-excerpt">${esc(p.text||'图片帖子')}</div><small>${num(p.images)} 张图片</small><a class="text-button" href="${esc(p.url)}" target="_blank" rel="noopener noreferrer">查看 X 原帖 ↗</a></td><td><span class="badge ${['sent','baseline'].includes(outcome(p))?'':'off'}">${esc(states[outcome(p)]||states.unknown)}</span><small>成功 ${p.deliveries.filter(d=>d.status==='sent').length} / 已尝试 ${p.deliveries.length} 段</small></td><td>${p.deliveries.length?p.deliveries.map(d=>`<div>第 ${d.part+1} 段 · ${esc(states[d.status]||states.unknown)} ${d.message_url?`<a class="text-button" href="${esc(d.message_url)}" target="_blank" rel="noopener noreferrer">TG 消息 ↗</a>`:''}</div>`).join(''):'尚未发送'}${p.previous_deliveries?.length?`<details><summary>之前发送记录（最近 ${p.previous_deliveries.length} 段）</summary>${p.previous_deliveries.map(d=>`<div>第 ${d.part+1} 段 ${d.message_url?`<a class="text-button" href="${esc(d.message_url)}" target="_blank" rel="noopener noreferrer">原 TG 消息 ↗</a>`:'已确认收到'}</div>`).join('')}</details>`:''}</td><td>${actions(p)}</td></tr>`);
 return list.length?table([...(choose?['选择']:[]),'X 发布时间（UTC+8）','帖子内容','状态','分段投递记录','人工操作'],rows):empty('没有符合条件的同步记录。');
}

function screen(s){
 const timerNames={active:'运行中',inactive:'已停止',failed:'调度失败',activating:'正在启动',not_installed:'未安装',unknown:'无法确认'};
 const timer=timerNames[s.timer.state]||'无法确认';
 if(!s.available)return panel('⇄ 同步状态尚未接入',`定时器：${timer}`,`<div class="empty">${s.reason==='not_configured'?'尚未收到转发工具的状态报告。更新转发工具后，后台才能显示真实记录。':'无法读取有效状态报告，请检查服务和文件权限。'}<p>网站没有发起 X 请求，也没有发送测试消息。</p></div>`);
 const counts=s.counts,delivery=s.delivery_counts;
 const blocked=delivery.uncertain+delivery.failed;
 let label=s.timer.state==='active'?'已启用 · 等待下一次检查':'调度状态：'+timer;
 if(s.last_error)label='需要关注：'+reason(s.last_error);
 if(blocked)label='发送已暂停核对：存在发送失败或结果不确定的记录';
 if(s.stale)label='状态报告已超过20分钟未更新，请检查转发服务';
 const cards=[['已发送帖子',counts.sent,'已完成所有分段的帖子'],['等待处理',counts.pending,'包含限流及需人工核对的帖子'],['历史基线',counts.baseline,'启用前旧帖，不补发'],['需核对分段',blocked,'失败或结果不确定，不自动重发']];
 return `<div class="stats">${cards.map(([title,value,foot])=>`<div class="stat"><div class="stat-top">${title}</div><div class="stat-value">${num(value)}</div><div class="stat-foot">${foot}</div></div>`).join('')}</div>`+
 panel('⇄ '+esc(label),'页面每15秒更新服务器状态；X 来源默认每10分钟检查一次。',`<div class="sync-route"><b>@${esc(s.source)}</b><span>→</span><b>@${esc(s.channel)}</b><span>机器人 @${esc(s.bot)}</span></div><dl class="sync-info"><div><dt>定时器</dt><dd>${esc(timer)} · ${s.timer.enabled===true?'已设开机启动':s.timer.enabled===false?'未设开机启动':'开机启动状态未知'}</dd></div><div><dt>启用时间</dt><dd>${clock(s.enabled_at)}</dd></div><div><dt>最近来源检查</dt><dd>${clock(s.last_check)}</dd></div><div><dt>最近检查成功</dt><dd>${clock(s.last_success)}</dd></div><div><dt>最近整帖发送成功</dt><dd>${clock(s.last_delivery)}</dd></div><div><dt>下次允许读取来源</dt><dd>${clock(s.next_fetch)}</dd></div><div><dt>下次调度时间</dt><dd>${esc(s.timer.next_run||'由服务器定时器安排')}</dd></div><div><dt>发送限流等待至</dt><dd>${s.next_send>s.server_time?clock(s.next_send):'无'}</dd></div><div><dt>状态报告更新时间</dt><dd>${clock(s.updated_at)}</dd></div></dl><p class="form-hint">自动任务只转发启用后的新帖；过往已抓取帖子可在下方选择人工同步。</p>`)+
 panel('最近检查结果',s.last_error?'最近失败：'+clock(s.last_error_at):'记录来自转发服务',`<p class="sync-notice">${esc(reason(s.last_error))}</p><p class="form-hint">刷新不触发额外抓取。具备人工发布权限的管理员可以选择过往已抓取帖子补发；默认跳过已发内容，重新发布需明确确认。</p>`)+
 panel('帖子与投递记录','最近100条已观察帖子；累计数量保留全部历史。',`<div class="toolbar"><input id="sync-search" aria-label="搜索同步帖子" placeholder="搜索正文或帖子 ID" value="${esc(query)}"><select id="sync-filter" aria-label="同步状态筛选">${[['all','全部状态'],...Object.entries(states).filter(([key])=>key!=='unknown')].map(([key,label])=>`<option value="${key}" ${filter===key?'selected':''}>${esc(label)}</option>`).join('')}</select></div><div id="sync-selection">${selectionBar()}</div><div id="sync-records">${records()}</div>`)+
 panel('人工操作记录','最近50次已处理请求；提交成功不代表已经投递成功。',table(['提交时间','管理员','帖子','操作','执行结果'],(s.requests||[]).map(r=>`<tr><td>${clock(r.created)}</td><td>${esc(r.actor)}</td><td>${esc(r.post_id)}</td><td>${r.action==='mark_sent'?'标记已收到并继续':r.action==='republish'?'重新发布（新增消息）':'人工发布／重试'}</td><td>${esc(({queued:'等待处理',processing:'处理中',completed:'已完成',failed:'未完成',interrupted:'中断，需核对频道'})[r.status]||r.status)}<small>${esc(r.detail==='sent'?'发送完成':r.detail==='post_changed_refresh'?'帖子状态已变化，请刷新后核对':r.detail==='already_sent'?'已发送，未重复发布':r.detail==='manual_rate_limit_wait'?'限流等待，请稍后重试':r.detail==='confirm_channel_first'?'请先核对频道':r.detail?reason(r.detail):'')}</small></td></tr>`)));

}
function paint(){
 if(page!=='sync'||!csrf||!accessAllowed(currentUser,'sync.view'))return;
 const slot=$('#sync-screen');if(!slot)return;
 slot.innerHTML=screen(latest);
 $('#sync-search')?.addEventListener('input',e=>{query=e.target.value;updateRecords();});
 $('#sync-filter')?.addEventListener('change',e=>{filter=e.target.value;updateRecords();});
}
async function load(){
 if(busy)return;busy=true;const session=csrf;
 try{const result=await api('/api/sync/status');if(csrf===session){latest=result;for(const [id,rev] of selected){const post=result.posts?.find(p=>p.id===id);if(!post||post.revision!==rev||!selectable(post))selected.delete(id);}for(const [pid,rid] of pending){if((result.requests||[]).some(r=>r.id===rid&&!['processing','queued'].includes(r.status)))pending.delete(pid);}paint();}}
 catch(error){if(page==='sync'&&csrf===session&&$('#sync-screen'))$('#sync-screen').innerHTML=empty(error.message);}
 finally{busy=false;}
}
document.addEventListener('change',e=>{
 const id=e.target.dataset.syncSelect;
 if(id){const post=latest?.posts.find(p=>p.id===id);if(!post||!selectable(post))return;
  if(e.target.checked){if(selected.size>=20){e.target.checked=false;toast('每次最多选择20条帖子');return;}selected.set(id,post.revision);}else selected.delete(id);
  if($('#sync-selection'))$('#sync-selection').innerHTML=selectionBar();
 }
 if(e.target.id==='sync-batch-mode')batchMode=e.target.value;
});
document.addEventListener('click',async e=>{
 const button=e.target.closest('button');if(!button)return;
 if(button.id==='sync-select-visible'){
  for(const post of visiblePosts()){if(selected.size>=20)break;if(selectable(post))selected.set(post.id,post.revision);}updateRecords();
 }
 if(button.id==='sync-clear-selection'){selected.clear();updateRecords();}
 if(button.id!=='sync-publish-selected')return;
 const all=[...selected.keys()].map(id=>latest.posts.find(p=>p.id===id)).filter(Boolean);
 const posts=all.filter(p=>selectable(p)&&(batchMode==='republish'?p.status==='sent':p.status!=='sent'));
 const skipped=all.length-posts.length;
 if(!posts.length){toast(batchMode==='republish'?'请选择已发送的帖子；未完成帖子请使用补发':'所选帖子已发送或不可补发；如需再次发送请选择重新发布');return;}
 const action=batchMode;
 const message=action==='republish'?`确认重新发布 ${posts.length} 条已发送帖子到 @coinwofficialchannel？这会新增频道消息，原消息保留。`:`确认补发所选 ${posts.length} 条帖子到 @coinwofficialchannel？已成功的分段将跳过。`;
 if(!confirm(message+(skipped?` 另有 ${skipped} 条不符合当前方式，将跳过。`:'')))return;
 const batch=posts.map(p=>({post_id:p.id,revision:selected.get(p.id)}));
 posts.forEach(p=>pending.set(p.id,'submitting'));paint();
 try{
  const result=await api('/api/sync/publish-batch',{posts:batch,action,confirmed:action==='republish'});
  const accepted=new Map((result.requests||[]).map(r=>[r.post_id,r.request_id]));
  for(const post of posts){if(accepted.has(post.id)){pending.set(post.id,accepted.get(post.id));selected.delete(post.id);}else pending.delete(post.id);}
  toast(result.ok?`已提交 ${accepted.size} 条人工同步请求${skipped?`，跳过 ${skipped} 条`:''}，请查看操作记录`:result.error);
  await load();
 }catch(error){posts.forEach(p=>pending.delete(p.id));toast(error.message);await load();paint();}
});
document.addEventListener('click',async e=>{
 const button=e.target.closest('[data-sync-action]');if(!button)return;
 const post=latest?.posts.find(p=>p.id===button.dataset.syncPost);if(!post||pending.has(post.id))return;
 const action=button.dataset.syncAction,uncertain=post.deliveries.some(d=>['uncertain','sending'].includes(d.status));
 let message=post.status==='baseline'?'这是启用前的旧帖，将人工发布到 @coinwofficialchannel。确认发布？':'将向 @coinwofficialchannel 发布未成功的分段，已成功分段会跳过。确认继续？';
 if(uncertain)message=action==='mark_sent'?'请先核对频道：确认本帖所有“结果待核对”的分段已经收到？确认后将标记这些分段已发送，并继续发布尚未发送的其余部分。':'请先核对频道：确认本帖“结果待核对”的分段没有收到？重新发送可能造成重复。确认重试？';
 if(action==='republish')message='这条帖子已成功发送。重新发布会在 @coinwofficialchannel 新增一份正文与图片，原消息不会删除。确认再次发布？';
 if(!confirm(message))return;
 selected.delete(post.id);
 pending.set(post.id,'submitting');paint();
 try{const result=await api('/api/sync/publish',{post_id:post.id,action,revision:post.revision,confirmed:uncertain||action==='republish'});pending.set(post.id,result.request_id);toast('人工发布请求已提交，执行结果请查看操作记录');await load();}
 catch(error){pending.delete(post.id);toast(error.message);await load();paint();}
});
const before=render;
render=function(){
 before();
 $('.context-bar').hidden=page==='sync';
 if(page==='sync'){
  $('#manage-disconnected').hidden=true;
  $('#content').innerHTML='<div id="sync-screen">'+empty('正在读取同步状态…')+'</div>';
  if(latest)paint();load();
 }
};
const logout=window.onAccessLogout;
window.onAccessLogout=()=>{latest=null;query='';filter='all';pending.clear();selected.clear();batchMode='publish';logout?.();};
})();
