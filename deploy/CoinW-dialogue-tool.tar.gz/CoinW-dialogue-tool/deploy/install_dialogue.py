#!/usr/bin/env python3
"""Install a reviewed local dialogue bundle onto the existing CoinW server."""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import pwd
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

SOURCE=Path(__file__).resolve().parents[1]
TARGET=Path('/opt/coinw')
DIALOGUE_HOME=Path('/var/lib/coinw/dialogue')
UNIT=Path('/etc/systemd/system/coinw-dialogue.service')
MARKER='# Managed by CoinW dialogue installer v1\n'


def run(args):
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=600)
    if result.returncode:raise ValueError('Installation command failed: '+args[0])


def atomic(path,body):
    fd,name=tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as output:
            os.fchmod(output.fileno(),0o644);output.write(body);output.flush();os.fsync(output.fileno())
        os.replace(name,path)
    finally:Path(name).unlink(missing_ok=True)


def existing_database():
    # Select the existing database path without printing or copying credential bindings.
    settings={}
    for line in Path('/etc/coinw/coinw.env').read_text().splitlines():
        if line.startswith(('DATABASE_PATH=','UI_MODE=')):
            key,value=line.split('=',1);settings[key]=value.strip().strip('"').strip("'")
    if settings.get('UI_MODE')=='hosted-preview':raise ValueError('Requires the real server dashboard, not the standalone preview')
    database=Path(settings.get('DATABASE_PATH','/var/lib/coinw/community.sqlite3'))
    if not database.is_absolute():database=TARGET/database
    if database.resolve().parent!=DIALOGUE_HOME.parent or not database.is_file():raise ValueError('Expected existing database under /var/lib/coinw')
    return database


def main():
    if os.geteuid()!=0:raise ValueError('Run with sudo python3 deploy/install_dialogue.py')
    if not (TARGET/'app.py').is_file():raise ValueError('Existing website was not found')
    if UNIT.exists() and not UNIT.read_text().startswith(MARKER):raise ValueError('Unmanaged worker service exists')
    database=existing_database()
    manifest=json.loads((SOURCE/'deploy/dialogue-release.json').read_text())
    contents={}
    for name,digest in manifest['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Invalid bundle path')
        body=(SOURCE/name).read_bytes()
        if hashlib.sha256(body).hexdigest()!=digest:raise ValueError('Bundle file checksum mismatch')
        if name.endswith('.py'):compile(body,name,'exec')
        contents[name]=body
    print('Bundle files verified. Preparing the isolated Telegram client environment.',flush=True)
    if not (TARGET/'dialogue-venv/bin/python').is_file():run(['/usr/bin/python3','-m','venv',str(TARGET/'dialogue-venv')])
    run([str(TARGET/'dialogue-venv/bin/python'),'-m','pip','install','--no-input','--require-hashes','--index-url','https://pypi.org/simple','-r',str(SOURCE/'deploy/dialogue-requirements.txt')])
    account=pwd.getpwnam('coinw')
    DIALOGUE_HOME.mkdir(mode=0o700,exist_ok=True)
    if DIALOGUE_HOME.is_symlink():raise ValueError('Dialogue home must be a real directory')
    os.chown(DIALOGUE_HOME,account.pw_uid,account.pw_gid);DIALOGUE_HOME.chmod(0o700)
    targets={TARGET/name:body for name,body in contents.items() if not name.startswith('deploy/')}
    targets[UNIT]=MARKER.encode()+contents['deploy/coinw-dialogue.service']
    backup=DIALOGUE_HOME.parent/'code-backups'/('dialogue-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'))
    backup.mkdir(parents=True,mode=0o700)
    previous={path:path.read_bytes() if path.exists() else None for path in targets}
    for index,(path,body) in enumerate(previous.items()):
        if body is not None:(backup/(str(index)+'.bin')).write_bytes(body)
    (backup/'files.json').write_text(json.dumps([str(path) for path in targets]))
    site_active=subprocess.run(['systemctl','is-active','--quiet','coinw'],capture_output=True).returncode==0
    worker_active=subprocess.run(['systemctl','is-active','--quiet','coinw-dialogue'],capture_output=True).returncode==0
    if UNIT.exists():run(['systemctl','stop','coinw-dialogue'])
    run(['systemctl','stop','coinw'])
    try:
        for dbpath,name in ((database,'website.sqlite3'),(DIALOGUE_HOME/'schedule.sqlite3','dialogue.sqlite3')):
            if dbpath.exists():
                with closing(sqlite3.connect(dbpath)) as source,closing(sqlite3.connect(backup/name)) as dest:source.backup(dest)
        for path,body in targets.items():
            path.parent.mkdir(parents=True,exist_ok=True);atomic(path,body)
        run(['systemd-analyze','verify',str(UNIT)])
        run(['systemctl','daemon-reload']);run(['systemctl','start','coinw'])
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for _ in range(50):
            try:
                with opener.open('http://127.0.0.1:8000/health',timeout=1) as response:
                    if json.load(response).get('ok'):break
            except OSError:time.sleep(.2)
        else:raise ValueError('Website readiness failed')
        with opener.open('http://127.0.0.1:8000/dialogue.js',timeout=3) as response:
            if response.read(200000)!=contents['static/dialogue.js']:raise ValueError('Dialogue page readiness failed')
        if worker_active:run(['systemctl','start','coinw-dialogue'])
    except BaseException:
        subprocess.run(['systemctl','stop','coinw-dialogue','coinw'],capture_output=True)
        for path,body in previous.items():
            if body is None:path.unlink(missing_ok=True)
            else:atomic(path,body)
        subprocess.run(['systemctl','daemon-reload'],capture_output=True)
        if site_active:subprocess.run(['systemctl','start','coinw'],capture_output=True)
        if worker_active:subprocess.run(['systemctl','start','coinw-dialogue'],capture_output=True)
        raise
    print('Dialogue page installed. Account sessions, website settings and databases were preserved.')
    print('Open https://panel.chloehub.top/?v=dialogue#dialogue and create account labels / group whitelist.')
    print('New worker is NOT started automatically. Complete server-side account login before enabling it.')


if __name__=='__main__':
    os.umask(0o077)
    try:main()
    except Exception:
        print('Installation stopped. Check bundle verification, Python venv support and existing website layout. Do not share credentials.',file=sys.stderr)
        sys.exit(1)
