"""Account-based, disclosed community dialogue scheduling. No credentials in HTTP APIs."""
from contextlib import contextmanager
from datetime import datetime, time as day_time, timedelta, timezone
import json
from pathlib import Path
import re
import sqlite3
import time

TZ = timezone(timedelta(hours=8))
PREFIX = '[运营互动] '


def integer(value, minimum, maximum):
    if isinstance(value, bool):
        raise ValueError('数字格式无效')
    try:
        result = int(value)
    except (TypeError, ValueError):
        raise ValueError('数字格式无效') from None
    if str(result) != str(value) or not minimum <= result <= maximum:
        raise ValueError(f'数值须在 {minimum}–{maximum} 范围内')
    return result


def label(value, limit=80):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError('名称不能为空或超出长度限制')
    return value.strip()


def validate_steps(steps):
    if not isinstance(steps, list) or not 1 <= len(steps) <= 100:
        raise ValueError('每个脚本需要1–100条消息')
    result=[];previous=-1
    for index, step in enumerate(steps):
        if not isinstance(step, dict):raise ValueError('脚本消息格式无效')
        at=step.get('time','')
        if not isinstance(at,str) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?',at):
            raise ValueError(f'第{index+1}条时间须为 HH:MM 或 HH:MM:SS（北京时间）')
        seconds=sum(int(part)*factor for part,factor in zip(at.split(':'),(3600,60,1)))
        if seconds<previous:raise ValueError('消息须按发送时间排序')
        previous=seconds
        text=label(step.get('text'),3500)
        if len((PREFIX+text).encode('utf-16-le'))//2>3900:
            raise ValueError('消息过长，请拆分')
        reply=step.get('reply_to')
        if reply not in (None,''):
            reply=integer(reply,1,index) if index else None
            if reply is None:raise ValueError('首条消息不能引用回复')
        else:reply=None
        result.append({'account_id':integer(step.get('account_id'),1,2**31),'time':at if len(at)==8 else at+':00',
                       'text':text,'reply_to':reply})
    return result


class Dialogues:
    def __init__(self,home):
        self.home=Path(home)
        self.home.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.path=self.home/'schedule.sqlite3'
        with self.db() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY,alias TEXT NOT NULL,
              min_interval INTEGER NOT NULL,daily_cap INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 0,
              connected INTEGER NOT NULL DEFAULT 0,username TEXT NOT NULL DEFAULT '',telegram_id INTEGER,
              last_attempt REAL NOT NULL DEFAULT 0,blocked_until REAL NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS groups(id INTEGER PRIMARY KEY,title TEXT NOT NULL,enabled INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY,title TEXT NOT NULL,group_id INTEGER NOT NULL,
              mode TEXT NOT NULL,start_date TEXT NOT NULL,end_date TEXT NOT NULL,steps TEXT NOT NULL,
              pause_on_human INTEGER NOT NULL,status TEXT NOT NULL,activated REAL NOT NULL DEFAULT 0,version INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY,plan_id INTEGER,day TEXT,version INTEGER,
              status TEXT NOT NULL,UNIQUE(plan_id,day,version));
            CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,run_id INTEGER,seq INTEGER,account_id INTEGER,
              due REAL,text TEXT,reply_seq INTEGER,status TEXT NOT NULL,message_id INTEGER,detail TEXT NOT NULL DEFAULT '',
              attempted REAL,sent_at REAL,UNIQUE(run_id,seq));
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,created REAL,actor TEXT,action TEXT,detail TEXT);
            CREATE TABLE IF NOT EXISTS worker(key TEXT PRIMARY KEY,value TEXT);
            ''')
        self.path.chmod(0o600)

    @contextmanager
    def db(self):
        db=sqlite3.connect(self.path,timeout=15)
        db.row_factory=sqlite3.Row
        try:
            with db:yield db
        finally:db.close()

    def audit(self,db,actor,action,detail):
        db.execute('INSERT INTO audit(created,actor,action,detail) VALUES(?,?,?,?)',(time.time(),actor,action,detail))

    def account(self,body,actor):
        alias=label(body.get('alias'))
        interval=integer(body.get('min_interval',60),5,86400)
        cap=integer(body.get('daily_cap',30),1,500)
        enabled=body.get('enabled',False)
        if type(enabled) is not bool:raise ValueError('启用状态无效')
        with self.db() as db:
            if body.get('id'):
                aid=integer(body['id'],1,2**31)
                if not db.execute('SELECT 1 FROM accounts WHERE id=?',(aid,)).fetchone():raise ValueError('账号不存在')
                db.execute('UPDATE accounts SET alias=?,min_interval=?,daily_cap=?,enabled=? WHERE id=?',(alias,interval,cap,int(enabled),aid))
            else:
                aid=db.execute('INSERT INTO accounts(alias,min_interval,daily_cap,enabled) VALUES(?,?,?,?)',(alias,interval,cap,int(enabled))).lastrowid
            self.audit(db,actor,'account',str(aid))
        return {'ok':True,'id':aid}

    def group(self,body,actor):
        gid=integer(body.get('id'),-(2**63),-1)
        enabled=body.get('enabled',True)
        if body.get('owned') is not True:raise ValueError('请确认这是你管理且允许自动互动的社群')
        if type(enabled) is not bool:raise ValueError('启用状态无效')
        title=label(body.get('title'))
        with self.db() as db:
            db.execute('INSERT INTO groups VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,enabled=excluded.enabled',(gid,title,int(enabled)))
            if not enabled:db.execute("UPDATE plans SET status='paused' WHERE group_id=?",(gid,))
            self.audit(db,actor,'group',str(gid))
        return {'ok':True}

    def save(self,body,actor):
        title=label(body.get('title'));steps=validate_steps(body.get('steps'))
        gid=integer(body.get('group_id'),-(2**63),-1)
        mode=body.get('mode','daily')
        if mode not in ('once','daily'):raise ValueError('执行方式无效')
        try:
            start=datetime.strptime(body['start_date'],'%Y-%m-%d').date()
            end=datetime.strptime(body.get('end_date') or body['start_date'],'%Y-%m-%d').date()
        except (ValueError,KeyError,TypeError):raise ValueError('日期须为 YYYY-MM-DD') from None
        if start>end or (end-start).days>366:raise ValueError('日期范围须在一年内')
        if mode=='once':end=start
        pause=body.get('pause_on_human',True)
        if type(pause) is not bool:raise ValueError('人工接管设置无效')
        with self.db() as db:
            if not db.execute('SELECT 1 FROM groups WHERE id=? AND enabled=1',(gid,)).fetchone():raise ValueError('请先配置已启用的群白名单')
            for aid in {step['account_id'] for step in steps}:
                if not db.execute('SELECT 1 FROM accounts WHERE id=?',(aid,)).fetchone():raise ValueError('脚本引用了不存在的账号')
            values=(title,gid,mode,start.isoformat(),end.isoformat(),json.dumps(steps,ensure_ascii=False),int(pause))
            if body.get('id'):
                pid=integer(body['id'],1,2**31)
                row=db.execute('SELECT * FROM plans WHERE id=?',(pid,)).fetchone()
                if not row:raise ValueError('计划不存在')
                if row['status']=='active':raise ValueError('请先暂停计划再编辑')
                if db.execute("SELECT 1 FROM jobs j JOIN runs r ON r.id=j.run_id WHERE r.plan_id=? AND j.status IN ('sending','uncertain')",(pid,)).fetchone():raise ValueError('存在发送中或待核对消息，请先核对处理')
                db.execute("UPDATE jobs SET status='cancelled' WHERE status='pending' AND run_id IN (SELECT id FROM runs WHERE plan_id=?)",(pid,))
                db.execute("UPDATE plans SET title=?,group_id=?,mode=?,start_date=?,end_date=?,steps=?,pause_on_human=?,status='draft',activated=0,version=version+1 WHERE id=?",(*values,pid))
            else:
                pid=db.execute("INSERT INTO plans(title,group_id,mode,start_date,end_date,steps,pause_on_human,status) VALUES(?,?,?,?,?,?,?,'draft')",values).lastrowid
            self.audit(db,actor,'save_plan',str(pid))
        return {'ok':True,'id':pid,'preview':self.preview(steps)}

    def preview(self,steps):
        return [{**step,'seq':index+1,'text':PREFIX+step['text']} for index,step in enumerate(steps)]

    def control(self,body,actor,now=None):
        now=time.time() if now is None else now
        pid=integer(body.get('id'),1,2**31);action=body.get('action')
        if action not in ('start','pause','cancel'):raise ValueError('计划操作无效')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT * FROM plans WHERE id=?',(pid,)).fetchone()
            if not row:raise ValueError('计划不存在')
            if action=='start':
                if row['status']=='cancelled':raise ValueError('已取消计划请另建草稿')
                if datetime.fromtimestamp(now,TZ).date().isoformat()>row['end_date']:raise ValueError('计划已超过结束日期')
                for step in json.loads(row['steps']):
                    account=db.execute('SELECT * FROM accounts WHERE id=?',(step['account_id'],)).fetchone()
                    if not account['enabled'] or not account['connected']:raise ValueError('请先在服务器登录并启用脚本中的全部账号')
                    if account['blocked_until']>now:raise ValueError('账号处于 Telegram 限流等待期')
                if not db.execute('SELECT 1 FROM groups WHERE id=? AND enabled=1',(row['group_id'],)).fetchone():raise ValueError('目标群不在启用白名单中')
                if db.execute("SELECT 1 FROM jobs j JOIN runs r ON r.id=j.run_id WHERE r.plan_id=? AND j.status IN ('sending','uncertain','failed','missed')",(pid,)).fetchone():raise ValueError('请先核对异常消息，编辑后重新排期；不要盲目恢复')
                db.execute("UPDATE plans SET status='active',activated=CASE WHEN activated=0 THEN ? ELSE activated END WHERE id=?",(now,pid))
            else:
                db.execute('UPDATE plans SET status=? WHERE id=?',('paused' if action=='pause' else 'cancelled',pid))
                if action=='cancel':db.execute("UPDATE jobs SET status='cancelled' WHERE status='pending' AND run_id IN (SELECT id FROM runs WHERE plan_id=?)",(pid,))
            self.audit(db,actor,action,str(pid))
        return {'ok':True}

    def resolve(self,body,actor):
        jid=integer(body.get('id'),1,2**63-1);action=body.get('action')
        if action not in ('received','not_received'):raise ValueError('核对操作无效')
        if body.get('confirmed') is not True:raise ValueError('请先核对群消息并确认结果')
        mid=integer(body.get('message_id'),1,2**31) if action=='received' else None
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            job=db.execute("SELECT * FROM jobs WHERE id=? AND status='uncertain'",(jid,)).fetchone()
            if not job:raise ValueError('消息状态已变化，请刷新')
            db.execute('UPDATE jobs SET status=?,message_id=?,detail=? WHERE id=?',('sent' if action=='received' else 'cancelled',mid,'manually_confirmed',jid))
            self.audit(db,actor,'resolve_'+action,str(jid))
        return {'ok':True}

    def recover(self):
        with self.db() as db:
            db.execute("UPDATE plans SET status='paused' WHERE id IN (SELECT r.plan_id FROM runs r JOIN jobs j ON j.run_id=r.id WHERE j.status='sending')")
            db.execute("UPDATE jobs SET status='uncertain',detail='worker_interrupted' WHERE status='sending'")

    def heartbeat(self,now=None):
        with self.db() as db:db.execute("INSERT OR REPLACE INTO worker VALUES('heartbeat',?)",(str(now if now is not None else time.time()),))

    def account_problem(self,aid,kind,wait=0):
        with self.db() as db:
            if kind=='session_invalid':db.execute('UPDATE accounts SET connected=0 WHERE id=?',(aid,))
            if wait:db.execute('UPDATE accounts SET blocked_until=? WHERE id=?',(time.time()+wait,aid))
            for plan in db.execute("SELECT id,steps FROM plans WHERE status='active'").fetchall():
                if any(step['account_id']==aid for step in json.loads(plan['steps'])):
                    db.execute("UPDATE plans SET status='paused' WHERE id=?",(plan['id'],))
            self.audit(db,'worker',kind,str(aid))

    def materialize(self,now):
        today=datetime.fromtimestamp(now,TZ).date()
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            for plan in db.execute("SELECT * FROM plans WHERE status='active'").fetchall():
                day=today.isoformat()
                if not plan['start_date']<=day<=plan['end_date']:continue
                if db.execute('SELECT 1 FROM runs WHERE plan_id=? AND day=? AND version=?',(plan['id'],day,plan['version'])).fetchone():continue
                rid=db.execute("INSERT INTO runs(plan_id,day,version,status) VALUES(?,?,?,'active')",(plan['id'],day,plan['version'])).lastrowid
                for index,step in enumerate(json.loads(plan['steps'])):
                    due=datetime.combine(today,day_time.fromisoformat(step['time']),TZ).timestamp()
                    status='skipped' if due<plan['activated'] else 'pending'
                    db.execute('INSERT INTO jobs(run_id,seq,account_id,due,text,reply_seq,status) VALUES(?,?,?,?,?,?,?)',
                               (rid,index+1,step['account_id'],due,PREFIX+step['text'],step['reply_to'],status))

    def claim(self,now):
        midnight=datetime.combine(datetime.fromtimestamp(now,TZ).date(),day_time(),TZ).timestamp()
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            rows=db.execute("""SELECT j.*,p.id AS plan_id,p.group_id FROM jobs j JOIN runs r ON r.id=j.run_id
               JOIN plans p ON p.id=r.plan_id WHERE j.status='pending' AND p.status='active' AND j.due<=? ORDER BY j.due,j.id""",(now,)).fetchall()
            for row in rows:
                account=db.execute('SELECT * FROM accounts WHERE id=?',(row['account_id'],)).fetchone()
                reason=''
                if not db.execute('SELECT 1 FROM groups WHERE id=? AND enabled=1',(row['group_id'],)).fetchone():reason='group_disabled'
                elif not account['enabled'] or not account['connected']:reason='account_unavailable'
                elif account['blocked_until']>now:reason='flood_wait'
                elif now-row['due']>300:reason='missed_window'
                if reason:
                    db.execute("UPDATE plans SET status='paused' WHERE id=?",(row['plan_id'],))
                    db.execute("UPDATE jobs SET status='missed',detail=? WHERE id=?",(reason,row['id']))
                    return None
                if db.execute("SELECT 1 FROM jobs WHERE run_id=? AND seq<? AND status IN ('pending','sending')",(row['run_id'],row['seq'])).fetchone():continue
                reply=None
                if row['reply_seq']:
                    parent=db.execute('SELECT status,message_id FROM jobs WHERE run_id=? AND seq=?',(row['run_id'],row['reply_seq'])).fetchone()
                    if parent['status']!='sent' or not parent['message_id']:
                        db.execute("UPDATE jobs SET status='failed',detail='reply_target_missing' WHERE id=?",(row['id'],))
                        db.execute("UPDATE plans SET status='paused' WHERE id=?",(row['plan_id'],));return None
                    reply=parent['message_id']
                if now<account['last_attempt']+account['min_interval']:continue
                count=db.execute("SELECT COUNT(*) FROM jobs WHERE account_id=? AND attempted>=? AND status IN ('sending','sent','uncertain')",(account['id'],midnight)).fetchone()[0]
                if count>=account['daily_cap']:
                    db.execute("UPDATE plans SET status='paused' WHERE id=?",(row['plan_id'],))
                    db.execute("UPDATE jobs SET detail='daily_cap' WHERE id=?",(row['id'],));return None
                db.execute("UPDATE jobs SET status='sending',attempted=? WHERE id=?",(now,row['id']))
                db.execute('UPDATE accounts SET last_attempt=? WHERE id=?',(now,account['id']))
                return dict(row)|{'reply_message_id':reply}
        return None

    def still_allowed(self,job):
        with self.db() as db:
            return bool(db.execute("SELECT 1 FROM plans p JOIN groups g ON p.group_id=g.id JOIN accounts a ON a.id=? WHERE p.id=? AND p.status='active' AND g.enabled=1 AND a.enabled=1",(job['account_id'],job['plan_id'])).fetchone())

    def finish(self,job,status,message_id=None,detail='',wait=0):
        if status not in ('sent','failed','uncertain','cancelled'):raise ValueError('invalid outcome')
        with self.db() as db:
            db.execute('UPDATE jobs SET status=?,message_id=?,detail=?,sent_at=? WHERE id=?',(status,message_id,detail,time.time() if status=='sent' else None,job['id']))
            if status in ('failed','uncertain'):
                db.execute("UPDATE plans SET status='paused' WHERE id=?",(job['plan_id'],))
                self.audit(db,'worker',status,str(job['id'])+':'+detail)
            if wait:db.execute('UPDATE accounts SET blocked_until=? WHERE id=?',(time.time()+wait,job['account_id']))
            if detail=='session_invalid':db.execute('UPDATE accounts SET connected=0 WHERE id=?',(job['account_id'],))

    def human_message(self,gid,sender_id):
        with self.db() as db:
            if db.execute('SELECT 1 FROM accounts WHERE telegram_id=?',(sender_id,)).fetchone():return
            for row in db.execute("SELECT id FROM plans WHERE group_id=? AND status='active' AND pause_on_human=1",(gid,)).fetchall():
                db.execute("UPDATE plans SET status='paused' WHERE id=?",(row['id'],))
                self.audit(db,'worker','human_pause',str(row['id']))

    def snapshot(self):
        with self.db() as db:
            accounts=[dict(row) for row in db.execute('SELECT * FROM accounts ORDER BY id')]
            plans=[]
            for row in db.execute('SELECT * FROM plans ORDER BY id DESC'):
                plan=dict(row);plan['steps']=json.loads(plan['steps']);plan['preview']=self.preview(plan['steps']);plans.append(plan)
            beat=db.execute("SELECT value FROM worker WHERE key='heartbeat'").fetchone()
            return {'accounts':accounts,'groups':[dict(row) for row in db.execute('SELECT * FROM groups')],
                    'plans':plans,'jobs':[dict(row) for row in db.execute('SELECT j.*,r.plan_id,r.day FROM jobs j JOIN runs r ON r.id=j.run_id ORDER BY j.id DESC LIMIT 200')],
                    'audit':[dict(row) for row in db.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 100')],
                    'worker_heartbeat':float(beat[0]) if beat else 0,'server_time':time.time(),'prefix':PREFIX}
