"""Read-only, credential-free status for the X forwarding dashboard."""
import json
import os
from pathlib import Path
import re
import subprocess
import time
import tempfile
import threading
import uuid

REPORT = Path('/var/lib/coinw-x-status/status.json')
REQUESTS = Path('/var/lib/coinw/x-forward-requests')
QUEUE_LOCK = threading.Lock()


def timer_status():
    try:
        result = subprocess.run(['systemctl', 'show', 'coinw-x-forward.timer',
                                 '--property=LoadState,ActiveState,UnitFileState,NextElapseUSecRealtime'],
                                capture_output=True, text=True, timeout=2)
        if result.returncode:
            return {'state': 'unknown', 'enabled': None, 'next_run': ''}
        values = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
        if values.get('LoadState') == 'not-found':
            state = 'not_installed'
        else:
            state = values.get('ActiveState', 'unknown')
        return {'state': state if state in ('not_installed', 'active', 'inactive', 'failed', 'activating') else 'unknown',
                'enabled': values.get('UnitFileState') == 'enabled',
                'next_run': values.get('NextElapseUSecRealtime', '')[:100]}
    except (OSError, subprocess.SubprocessError, ValueError):
        return {'state': 'unknown', 'enabled': None, 'next_run': ''}


def snapshot():
    now = time.time()
    result = {'available': False, 'server_time': now, 'timer': timer_status(), 'posts': []}
    try:
        with REPORT.open('rb') as stream:
            raw = stream.read(1_000_001)
        if len(raw) > 1_000_000:
            raise ValueError()
        data = json.loads(raw)
        if data.get('version') != 1:
            raise ValueError()
        result.update(available=True, source='CoinWOfficial', channel='coinwofficialchannel', bot='CoinWCommunityHubBot', interval_seconds=600)
        result['manual_supported'] = data.get('manual_supported') is True and REQUESTS.is_dir()
        result['republish_supported'] = result['manual_supported'] and data.get('republish_supported') is True
        result['requests'] = []
        for request in data.get('requests', [])[:50]:
            if not re.fullmatch(r'[a-f0-9]{32}', str(request.get('id',''))):continue
            result['requests'].append({key:str(request.get(key,''))[:150] for key in ('id','post_id','actor','action','status','detail')}
                                      | {'created':float(request['created'])})
        known = {request['id'] for request in result['requests']}
        for path in list(REQUESTS.glob('*.json'))[:50]:
            try:
                if path.is_symlink() or path.stat().st_size>8192:continue
                request=json.loads(path.read_text())
                if request['id'] in known or not re.fullmatch(r'[a-f0-9]{32}',request['id']):continue
                result['requests'].append({key:str(request.get(key,''))[:100] for key in ('id','post_id','actor','action')}
                                          | {'created':float(request['created']),'status':'queued','detail':''})
            except (OSError,ValueError,TypeError,KeyError):
                continue
        result['requests']=sorted(result['requests'],key=lambda request:request['created'],reverse=True)[:50]
        for key in ('updated_at', 'enabled_at', 'last_check', 'last_success', 'last_delivery', 'next_fetch', 'next_send', 'last_error_at'):
            value = float(data.get(key, 0))
            if not 0 <= value < 1e12:
                raise ValueError()
            result[key] = value
        # Never expose arbitrary error text or unrecognized fields from the file.
        error = str(data.get('last_error', ''))
        result['last_error'] = error if re.fullmatch(r'[a-z_]*(?:_post_\d+)?', error) else 'unknown_error'
        for field, states in (('counts', ('baseline', 'pending', 'sent')), ('delivery_counts', ('sent', 'sending', 'uncertain', 'failed', 'retry'))):
            result[field] = {key: max(0, int(data.get(field, {}).get(key, 0))) for key in states}
        for post in data.get('posts', [])[:100]:
            pid = str(post['id'])
            if not re.fullmatch(r'\d{1,30}', pid):
                continue
            item = {'id': pid, 'url': 'https://x.com/CoinWOfficial/status/' + pid,
                    'published': float(post['published']), 'text': str(post['text'])[:1200],
                    'images': max(0, int(post['images'])),
                    'status': post['status'] if post['status'] in ('baseline', 'pending', 'sent') else 'unknown', 'deliveries': []}
            item['revision'] = str(post.get('revision','')) if re.fullmatch(r'[a-f0-9]{64}',str(post.get('revision',''))) else ''
            for delivery in post.get('deliveries', [])[:100]:
                state = delivery.get('status')
                mid = delivery.get('message_id')
                item['deliveries'].append({'part': int(delivery['part']),
                    'status': state if state in ('sending', 'sent', 'uncertain', 'failed', 'retry') else 'unknown',
                    'message_url': f'https://t.me/coinwofficialchannel/{mid}' if isinstance(mid, int) and mid > 0 else None})
            item['previous_deliveries'] = []
            for delivery in post.get('previous_deliveries', [])[:20]:
                mid = delivery.get('message_id')
                item['previous_deliveries'].append({'part':int(delivery['part']), 'archived_at':float(delivery['archived_at']),
                    'message_url':f'https://t.me/coinwofficialchannel/{mid}' if isinstance(mid,int) and mid>0 else None})
            result['posts'].append(item)
        result['stale'] = now - result['updated_at'] > 1200
        return result
    except FileNotFoundError:
        return {'available': False, 'reason': 'not_configured', 'server_time': now, 'timer': result['timer'], 'posts': []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, OverflowError):
        return {'available': False, 'reason': 'report_unavailable', 'server_time': now, 'timer': result['timer'], 'posts': []}


def prepare_request(body, user, data):
    if (not isinstance(body,dict) or not isinstance(body.get('post_id'),str) or not re.fullmatch(r'\d{1,30}',body['post_id'])
            or body.get('action') not in ('publish','mark_sent','republish')
            or not isinstance(body.get('revision'),str) or not re.fullmatch(r'[a-f0-9]{64}',body['revision'])):
        raise ValueError('同步操作参数无效，请刷新页面后重试')
    if not data.get('manual_supported'):
        raise ValueError('服务器尚未启用人工发布功能，请先更新转发工具')
    post = next((p for p in data['posts'] if p['id']==body['post_id']),None)
    if not post or post['revision']!=body['revision']:
        raise ValueError('帖子状态已变化，请刷新后重试')
    if body['action']=='republish':
        if not data.get('republish_supported'):
            raise ValueError('服务器尚未启用重新发布，请先更新转发工具')
        if post['status']!='sent' or body.get('confirmed') is not True:
            raise ValueError('请明确确认重新发布已发送的帖子，这会新增频道消息')
    elif post['status']=='sent':
        raise ValueError('该帖已发送，不重复发布；如需再次发送请选择重新发布')
    if data.get('next_send',0)>time.time():
        raise ValueError('Telegram 正在限流，请等待页面显示的重试时间')
    ambiguous = any(d['status'] in ('sending','uncertain') for d in post['deliveries'])
    if (ambiguous or body['action']=='mark_sent') and body.get('confirmed') is not True:
        raise ValueError('请先核对 TG 频道并明确确认处理方式')
    request = {key:body[key] for key in ('post_id','action','revision')}
    request.update(id=uuid.uuid4().hex,actor=user['username'],confirmed=body.get('confirmed') is True,created=time.time())
    return request


def commit_requests(requests):
    with QUEUE_LOCK:
        if len(list(REQUESTS.glob('*.json')))+len(requests)>50:
            raise ValueError('人工发布队列繁忙，请稍后重试')
        staged=[];accepted=[]
        try:
            # Validate and stage the complete batch before exposing any requests to the worker.
            for request in requests:
                fd, name = tempfile.mkstemp(dir=REQUESTS,prefix='.request-')
                staged.append((name,request))
                with os.fdopen(fd,'w') as output:
                    json.dump(request,output)
                    output.flush();os.fsync(output.fileno())
            for name,request in staged:
                os.replace(name,REQUESTS/(request['id']+'.json'))
                accepted.append({'ok':True,'post_id':request['post_id'],'action':request['action'],
                                 'request_id':request['id'],'status':'queued'})
        except OSError:
            if not accepted:raise
            # A late filesystem failure cannot recall an already visible request.
            return {'ok':False,'requests':accepted,'error':'部分请求已提交，剩余请求未提交；请查看操作记录后重试剩余帖子'}
        finally:
            for name,_ in staged:Path(name).unlink(missing_ok=True)
    return {'ok':True,'requests':accepted}


def enqueue(body, user):
    request=prepare_request(body,user,snapshot())
    return commit_requests([request])['requests'][0]


def enqueue_batch(body, user):
    posts=body.get('posts')
    if (not isinstance(posts,list) or not 1<=len(posts)<=20
            or body.get('action') not in ('publish','republish')):
        raise ValueError('每次请选择1至20条帖子，并指定补发或重新发布')
    data=snapshot();requests=[];seen=set()
    for post in posts:
        if not isinstance(post,dict):raise ValueError('帖子参数无效')
        request=prepare_request({'post_id':post.get('post_id'),'revision':post.get('revision'),
                                 'action':body['action'],'confirmed':body.get('confirmed')},user,data)
        if request['post_id'] in seen:raise ValueError('请勿重复选择同一条帖子')
        seen.add(request['post_id']);requests.append(request)
    return commit_requests(requests)
