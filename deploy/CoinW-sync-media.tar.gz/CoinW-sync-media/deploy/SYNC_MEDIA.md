# X GIF／视频同步升级

更新范围：独立转发器 x_to_telegram.py、网站只读状态 sync_status.py、同步页 sync.js。保留 X 登录、Token、原始启用时间、私有转发数据库及发送记录；不更新公告、群管理或对话工具。先备份代码及转发数据库，验证网站失败时回滚代码。

## 媒体支持

- 已核对部署所用 RSSHub 源码 c24abfcedd66168ad47cf41d9e023cf2990c0b44。其 GIF 输出为带 loop 标记的 video MP4。旧转发器只读 img 标签，只发 sendPhoto，因此会漏掉该媒体。
- 新版解析 HTML video/src/source、RSS enclosure、Media RSS，以及 pbs.twimg.com GIF；循环MP4/真实GIF走 sendAnimation，普通MP4走 sendVideo 并设置 supports_streaming。静态图继续 sendPhoto。正文、长 Unicode、caption 和 View on X 按钮保留。
- HTTPS媒体仅允许 pbs.twimg.com 图片/GIF、video.twimg.com MP4；不接受任意主机、凭据、特殊端口、HLS清单。由 Telegram 获取媒体，最终接收还取决于源链接可用性及Telegram格式、大小限制。不会把视频封面冒充动图。
- 新帖自动同步。已有发送尝试的帖子保持原正文、图片和分段位置，新发现的动图／视频追加到计划末尾，不自动重发已完成旧帖。
- 完成旧帖发现遗漏媒体后，页面显示“已发部分内容 · 待补媒体”，提供“仅补发缺失媒体”。该操作经原登录、CSRF、sync.manage 权限及私有队列执行；跳过已成功文字和图片。来源媒体变化会使旧操作修订值失效，防止旧页面误发。
- 429遵守等待，超时/断连/发送中退出保持结果待核对，不盲目重试；失败帖子隔离，已成功分段不重发。延续自动/人工投递来源区分及局部HTTP400错误隔离。

## 安装

sudo python3 deploy/install_sync_media.py

成功输出：Media sync installed.

升级包本身不包含任何账号凭据，也不重建RSSHub容器。

## 指定帖子恢复媒体（只读来源，不发送TG）

sudo python3 /opt/coinw-x-forward/x_to_telegram.py refresh-media --post-id 2120844052983857396

命令只读取本机RSSHub的 /twitter/tweet/CoinWOfficial/status/<id>，要求该帖已存在私有库。每个帖子10分钟内最多刷新一次，不接受自定义URL。若上游不可用、登录失效或未返回该帖子，保留原内容并显示固定错误码；不自动猜测或制造媒体。

成功时输出 animations/videos/missing_media 的数量。随后强制刷新：
https://panel.chloehub.top/?v=sync-media#sync

搜索帖子ID并点击“仅补发缺失媒体”，核对最终TG播放结果。若该帖子已由其他方式补过动图，请先核对，避免再次补发。不要使用“重新发布”来代替仅补媒体，那会重发整帖。

自动轮询也会更新订阅窗口内既有帖子的媒体。如果旧帖已超出窗口，可用上述单帖来源刷新命令。

## 验证边界

本地使用与部署RSSHub版本一致的媒体HTML样例，测试循环MP4/视频/GIF、多个sources、封面去重、媒体RSS、Unicode、历史分段位置、补发去重、重启/429/超时、队列与权限、安装回滚，并以真实浏览器验证。Telegram发送为模拟，未向实际频道发送测试消息。用户所给X链接在当前开发环境返回403，未声称已取得它的实际媒体地址；服务器上的单帖刷新用于核实这一点。
