#!/usr/bin/env python3
"""One-shot X RSS -> Telegram worker; systemd timer supplies the schedule."""
from contextlib import closing
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET

ACCOUNT = 'CoinWOfficial'
CHANNEL = '@coinwofficialchannel'
BOT = 'CoinWCommunityHubBot'
FEED = 'http://127.0.0.1:1200/twitter/user/' + ACCOUNT
STATE = Path('/var/lib/coinw-x-forward')
PUBLIC = Path('/var/lib/coinw-x-status/status.json')
REQUESTS = Path('/var/lib/coinw/x-forward-requests')


class Failure(Exception):
    pass


class TelegramFailure(Failure):
    def __init__(self, kind, delay=0, detail=''):
        super().__init__(kind)
        self.kind, self.delay = kind, delay
        self.detail = detail or kind


def media_url(value, kind):
    """Only public X CDN media can enter a Telegram send request."""
    if not isinstance(value,str) or len(value)>4096 or re.search(r'[\s\\\x00-\x1f\x7f]',value):return False
    try:
        url=urlsplit(value)
        if url.scheme!='https' or url.username or url.password or url.port not in (None,443) or url.fragment:return False
        if kind=='photo':return url.hostname=='pbs.twimg.com' and bool(url.path)
        return ((url.hostname=='video.twimg.com' and url.path.lower().endswith('.mp4')) or
                (kind=='animation' and url.hostname=='pbs.twimg.com' and url.path.lower().endswith('.gif')))
    except ValueError:return False


def media_kind(url, animated=False):
    return 'animation' if animated or '/tweet_video/' in urlsplit(url).path or urlsplit(url).path.lower().endswith('.gif') else 'video'


def media_key(item):
    url=urlsplit(item['url'])
    return (url.hostname,url.path)  # CDN query tags do not identify a different clip.


class Content(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.images, self.media, self.hidden = [], [], [], 0
        self.video=None
        self.posters=set()

    def add_media(self,kind,url):
        if not media_url(url,kind):return
        item={'kind':kind,'url':url}
        if any(media_key(item)==media_key(existing) for existing in self.media):return
        self.media.append(item)
        if kind=='photo':self.images.append(url)

    def finish_video(self):
        if self.video and self.video['sources']:
            def quality(url):
                dimensions=re.search(r'/(\d+)x(\d+)/',urlsplit(url).path)
                return int(dimensions[1])*int(dimensions[2]) if dimensions else 0
            source=max(self.video['sources'],key=quality)
            self.add_media(media_kind(source,self.video['animated']),source)
            if media_url(self.video['poster'],'photo'):
                self.posters.add(media_key({'url':self.video['poster']}))
        self.video=None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ('script', 'style'):
            self.hidden += 1
        if self.hidden:
            return
        if tag in ('p', 'div', 'br'):
            self.parts.append('\n')
        if tag == 'a':
            href = attrs.get('href', '')
            if href.startswith(('https://', 'http://')):
                self.parts.append(' ' + href + ' ')
        if tag == 'img':
            src = attrs.get('src', '')
            self.add_media('animation' if re.search(r'\.gif(?:\?|$)',src,re.I) else 'photo',src)
        if tag=='video':
            self.finish_video()
            self.video={'animated':'loop' in attrs,'sources':[],'poster':attrs.get('poster','')}
        if tag in ('video','source') and self.video is not None:
            src=attrs.get('src','')
            if media_url(src,'video'):self.video['sources'].append(src)

    def handle_endtag(self, tag):
        if tag in ('script', 'style') and self.hidden:
            self.hidden -= 1
        if tag in ('p', 'div') and not self.hidden:
            self.parts.append('\n')
        if tag=='video' and not self.hidden:self.finish_video()

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def parse_feed(body):
    if len(body) > 2_000_000 or b'<!DOCTYPE' in body.upper() or b'<!ENTITY' in body.upper():
        raise Failure('feed_rejected')
    try:
        root = ET.fromstring(body)
        if root.tag != 'rss':
            raise ValueError()
        posts = {}
        for item in root.findall('./channel/item'):
            url = urlsplit(item.findtext('link', '').strip())
            match = re.fullmatch(r'/CoinWOfficial/status/(\d+)/?', url.path, re.I)
            if url.hostname not in ('x.com', 'twitter.com', 'www.x.com', 'www.twitter.com') or not match:
                continue
            date = parsedate_to_datetime(item.findtext('pubDate', ''))
            if date.tzinfo is None:
                raise ValueError()
            content = Content()
            content.feed(item.findtext('description', '') or item.findtext('{http://purl.org/rss/1.0/modules/content/}encoded','') or item.findtext('title', ''))
            content.finish_video()
            for attachment in item.iter():
                if attachment.tag not in ('enclosure','{http://search.yahoo.com/mrss/}content'):continue
                src=attachment.get('url','');mime=attachment.get('type','')
                if media_url(src,'animation') and urlsplit(src).path.lower().endswith('.gif'):
                    content.add_media('animation',src)
                elif mime.startswith('video/') and media_url(src,'video'):
                    content.add_media(media_kind(src),src)
                elif mime.startswith('image/'):
                    content.add_media('photo',src)
            content.media=[m for m in content.media if m['kind']!='photo' or media_key(m) not in content.posters]
            content.images=[m['url'] for m in content.media if m['kind']=='photo']
            text = '\n'.join(re.sub(r'[ \t]+', ' ', line).strip() for line in ''.join(content.parts).splitlines()).strip()
            if not text and not content.media:
                continue
            pid = match[1]
            posts[pid] = dict(id=pid, published=date.timestamp(), text=text, images=content.images,media=content.media,
                              url=f'https://x.com/{ACCOUNT}/status/{pid}')
        if not posts:
            raise ValueError()
        return sorted(posts.values(), key=lambda post: (post['published'], int(post['id'])))
    except (ValueError, TypeError, OverflowError, ET.ParseError):
        raise Failure('feed_invalid_or_no_posts') from None


def fetch_feed(url=FEED):
    try:
        # Only the fixed loopback RSSHub endpoint bypasses outbound proxies.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url, timeout=60) as response:
            body = response.read(2_000_001)
        return parse_feed(body)
    except (OSError, ValueError):
        raise Failure('rsshub_unavailable_check_login_or_rate_limit') from None


def telegram(token, method, data):
    if not re.fullmatch(r'\d+:[\w-]+', token, re.ASCII):
        raise Failure('existing_telegram_token_missing')
    request = urllib.request.Request('https://api.telegram.org/bot' + token + '/' + method,
                                     data=json.dumps(data).encode(), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            result = json.loads(response.read(1_000_000))
    except urllib.error.HTTPError as error:
        if error.code == 429:
            try:
                delay = int(json.loads(error.read(65536)).get('parameters', {}).get('retry_after', 600))
            except (ValueError, TypeError, OSError):
                delay = 600
            raise TelegramFailure('rate_limited', max(600, delay), 'http_429') from None
        raise TelegramFailure('uncertain' if error.code >= 500 else 'rejected', detail='http_'+str(error.code)) from None
    except (OSError, ValueError) as error:
        # Telegram may have accepted a timed-out request. Never blindly resend.
        timeout = isinstance(error, TimeoutError) or (isinstance(error, urllib.error.URLError) and isinstance(error.reason, TimeoutError))
        detail = 'request_timeout' if timeout else 'invalid_response' if isinstance(error, ValueError) else 'connection_error'
        raise TelegramFailure('uncertain', detail=detail) from None
    if not isinstance(result, dict):
        raise TelegramFailure('uncertain', detail='invalid_response')
    if not result.get('ok'):
        if result.get('error_code') == 429:
            raise TelegramFailure('rate_limited', max(600, int(result.get('parameters', {}).get('retry_after', 600))))
        code = result.get('error_code')
        raise TelegramFailure('rejected', detail='http_'+str(code) if type(code) is int and 400<=code<=599 else 'rejected')
    if 'result' not in result:
        raise TelegramFailure('uncertain', detail='invalid_response')
    return result['result']


def preflight(call):
    me = call('getMe', {})
    if me.get('username', '').lower() != BOT.lower():
        raise Failure('unexpected_bot')
    chat = call('getChat', {'chat_id': CHANNEL})
    if chat.get('type') != 'channel' or chat.get('username', '').lower() != CHANNEL[1:].lower():
        raise Failure('unexpected_channel')
    member = call('getChatMember', {'chat_id': chat['id'], 'user_id': me['id']})
    if member.get('status') != 'creator' and not (member.get('status') == 'administrator' and member.get('can_post_messages')):
        raise Failure('bot_cannot_post')


def chunks(text, limit=3900):
    result, part, size = [], '', 0
    for char in text:
        width = 2 if ord(char) > 0xffff else 1
        if size + width > limit:
            result.append(part)
            part, size = '', 0
        part += char
        size += width
    if part:
        result.append(part)
    return result


def plan(post):
    button = {'inline_keyboard': [[{'text': 'View on X', 'url': post['url']}]]}
    steps = []
    text = post['text']
    media=post.get('media')
    if media is None:media=[{'kind':'photo','url':url} for url in post['images']]
    caption = text if len(text.encode('utf-16-le')) // 2 <= 1000 and media else ''
    if text and not caption:
        for part in chunks(text):
            steps.append(('sendMessage', {'chat_id': CHANNEL, 'text': part, 'reply_markup': button,
                                          'link_preview_options': {'is_disabled': True}}))
    for index, item in enumerate(media):
        method,data=media_step(item,button)
        if index == 0 and caption:
            data['caption'] = caption
        steps.append((method, data))
    # Legacy deliveries keep their original segment positions; only append media.
    for item in post.get('media_extra',[]):steps.append(media_step(item,button))
    return steps


def media_step(item,button):
    method,field={'photo':('sendPhoto','photo'),'animation':('sendAnimation','animation'),'video':('sendVideo','video')}[item['kind']]
    if not media_url(item['url'],item['kind']):raise Failure('stored_media_invalid')
    data={'chat_id':CHANNEL,field:item['url'],'reply_markup':button}
    if item['kind']=='video':data['supports_streaming']=True
    return method,data


def missing_media(db,pid,post=None):
    if post is None:
        row=db.execute('SELECT payload FROM posts WHERE id=?',(pid,)).fetchone()
        if not row:return 0
        post=json.loads(row[0])
    base=len(plan({**post,'media_extra':[]}))
    return sum(not db.execute("SELECT 1 FROM deliveries WHERE post_id=? AND part=? AND status='sent'",(pid,base+i)).fetchone()
               for i in range(len(post.get('media_extra',[]))))


def enrich_post(db,post):
    row=db.execute('SELECT * FROM posts WHERE id=?',(post['id'],)).fetchone()
    if not row:return
    old=json.loads(row['payload'])
    # Before any attempt the complete new media plan can safely replace the old one.
    attempted=db.execute('SELECT 1 FROM deliveries WHERE post_id=?',(post['id'],)).fetchone()
    if not attempted and row['status']!='sent':
        if post.get('media') and not old.get('media_extra'):
            db.execute('UPDATE posts SET payload=? WHERE id=?',(json.dumps(post),post['id']))
        return
    existing=old.get('media', [{'kind':'photo','url':url} for url in old.get('images',[])])+old.get('media_extra',[])
    known={media_key(item) for item in existing}
    extras=[]
    for item in post.get('media',[]):
        if item['kind'] in ('animation','video') and media_key(item) not in known:
            extras.append(item);known.add(media_key(item))
    if extras:
        old['media_extra']=old.get('media_extra',[])+extras
        db.execute('UPDATE posts SET payload=? WHERE id=?',(json.dumps(old),post['id']))


def refresh_media(db,pid,now):
    """Explicit read-only source refresh for a known post, never a Telegram send."""
    if not isinstance(pid,str) or not re.fullmatch(r'\d{1,30}',pid):raise Failure('invalid_post_id')
    if not db.execute('SELECT 1 FROM posts WHERE id=?',(pid,)).fetchone():raise Failure('post_not_found')
    key='last_media_refresh_'+pid
    if now-float(get(db,key))<600:raise Failure('media_refresh_cooldown')
    with db:put(db,key,now)
    source=f'http://127.0.0.1:1200/twitter/tweet/{ACCOUNT}/status/{pid}'
    post=next((p for p in fetch_feed(source) if p['id']==pid),None)
    if post is None:raise Failure('feed_post_not_found')
    with db:enrich_post(db,post)
    return {'animations':sum(m['kind']=='animation' for m in post.get('media',[])),
            'videos':sum(m['kind']=='video' for m in post.get('media',[])),
            'missing_media':missing_media(db,pid)}


def connect(path):
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.executescript('''
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS posts(id TEXT PRIMARY KEY,payload TEXT NOT NULL,status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS deliveries(post_id TEXT,part INTEGER,status TEXT NOT NULL,message_id INTEGER,
            PRIMARY KEY(post_id,part));
        CREATE TABLE IF NOT EXISTS manual_requests(id TEXT PRIMARY KEY,post_id TEXT,actor TEXT,action TEXT,
            status TEXT,detail TEXT,created REAL,completed REAL);
        CREATE TABLE IF NOT EXISTS delivery_history(request_id TEXT,post_id TEXT,part INTEGER,status TEXT,
            message_id INTEGER,archived_at REAL,PRIMARY KEY(request_id,part));
    ''')
    return db


def get(db, key, default='0'):
    row = db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return row[0] if row else default


def put(db, key, value):
    db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)', (key, str(value)))


def initialize(db, posts, now):
    if get(db, 'enabled_at', ''):
        return False
    # Starting/reinstalling must never backfill feed history.
    with db:
        put(db, 'enabled_at', now)
        put(db, 'next_fetch', now + 600)
        for post in posts:
            db.execute('INSERT OR IGNORE INTO posts VALUES(?,?,?)', (post['id'], json.dumps(post), 'baseline'))
    return True


def stage_posts(db, posts, now):
    if not get(db, 'enabled_at', ''):
        raise Failure('not_initialized')
    with db:
        # Durable sending marker survives process death; uncertain sends require manual inspection.
        for row in db.execute("SELECT post_id,part FROM deliveries WHERE status='sending'").fetchall():
            put(db, 'delivery_error_'+row['post_id']+'_'+str(row['part']), 'worker_interrupted')
        db.execute("UPDATE deliveries SET status='uncertain' WHERE status='sending'")
        for post in posts:
            enrich_post(db,post)
            if float(get(db, 'enabled_at')) < post['published'] <= now + 60:
                db.execute('INSERT OR IGNORE INTO posts VALUES(?,?,?)', (post['id'], json.dumps(post), 'pending'))


def cycle(db, posts, call, now, only_post=None):
    stage_posts(db, posts, now)
    if now < float(get(db, 'next_send')):
        return
    content_error=None
    for row in db.execute("SELECT * FROM posts WHERE status='pending' ORDER BY CAST(id AS INTEGER)").fetchall():
        if only_post is not None and row['id'] != only_post:
            continue
        # Quarantine the whole affected post, including unattempted parts. Other
        # posts remain deliverable; uncertain content is never blindly replayed.
        if db.execute("SELECT 1 FROM deliveries WHERE post_id=? AND status IN ('uncertain','failed')", (row['id'],)).fetchone():
            if only_post is not None:
                raise Failure('delivery_requires_inspection_post_' + row['id'])
            continue
        steps = plan(json.loads(row['payload']))
        rejected_post=False
        for index, (method, data) in enumerate(steps):
            delivery = db.execute('SELECT status FROM deliveries WHERE post_id=? AND part=?', (row['id'], index)).fetchone()
            if delivery and delivery[0] == 'sent':
                continue
            if delivery and delivery[0] in ('uncertain', 'failed'):
                raise Failure('delivery_requires_inspection_post_' + row['id'])
            with db:
                db.execute('INSERT OR REPLACE INTO deliveries VALUES(?,?,?,NULL)', (row['id'], index, 'sending'))
            try:
                result = call(method, data)
                if not isinstance(result, dict) or not isinstance(result.get('message_id'), int):
                    raise TelegramFailure('uncertain')
            except TelegramFailure as error:
                with db:
                    status = {'rate_limited': 'retry', 'rejected': 'failed'}.get(error.kind, 'uncertain')
                    db.execute('UPDATE deliveries SET status=? WHERE post_id=? AND part=?', (status, row['id'], index))
                    put(db, 'delivery_error_'+row['id']+'_'+str(index), error.detail)
                    if error.delay:
                        put(db, 'next_send', now + error.delay)
                failure='telegram_' + error.kind + '_post_' + row['id']
                if only_post is None and error.kind=='rejected' and error.detail=='http_400':
                    # A conclusive bad request is local to this post. Continue
                    # other posts in this run; global auth/429/network errors stop.
                    content_error=failure
                    rejected_post=True
                    break
                raise Failure(failure) from None
            with db:
                db.execute("UPDATE deliveries SET status='sent',message_id=? WHERE post_id=? AND part=?", (result['message_id'], row['id'], index))
                put(db, 'delivery_error_'+row['id']+'_'+str(index), '')
                put(db, 'delivery_origin_'+row['id']+'_'+str(index), 'manual' if only_post is not None else 'auto')
                put(db, 'last_manual_delivery' if only_post is not None else 'last_auto_delivery', time.time())
        if rejected_post:
            continue
        with db:
            db.execute("UPDATE posts SET status='sent' WHERE id=?", (row['id'],))
            put(db, 'last_delivery', time.time())
        print('Forwarded post ' + row['id'], flush=True)
    if content_error:
        raise Failure(content_error)


def run_once(db, call, now):
    """Read the source on its own schedule; drain safe cached work independently."""
    if not get(db, 'enabled_at', ''):
        raise Failure('not_initialized')
    posts=[]
    source_error=get(db, 'last_feed_error', '')
    if now >= float(get(db, 'next_fetch')):
        with db:
            put(db, 'next_fetch', now + 600)
            put(db, 'last_check', now)
        try:
            posts=fetch_feed()
        except Failure as error:
            source_error=str(error)
            with db:
                failures=int(get(db, 'feed_failures'))+1
                put(db, 'feed_failures', failures)
                put(db, 'last_feed_error', source_error)
                put(db, 'next_fetch', now + min(21600, 600 * 2 ** min(failures, 5)))
        else:
            source_error=''
            with db:
                put(db, 'feed_failures', 0)
                put(db, 'last_feed_error', '')
                put(db, 'last_fetch_success', now)
    stage_posts(db, posts, now)
    ready=db.execute("""SELECT 1 FROM posts p WHERE p.status='pending' AND NOT EXISTS
        (SELECT 1 FROM deliveries d WHERE d.post_id=p.id AND d.status IN ('failed','uncertain','sending')) LIMIT 1""").fetchone()
    if ready and now >= float(get(db, 'next_send')):
        try:
            preflight(call)
        except TelegramFailure as error:
            raise Failure('telegram_preflight_'+error.kind) from None
        cycle(db, [], call, now)
    # Source errors remain visible even when cached posts were delivered.
    if source_error:
        raise Failure(source_error)
    with db:
        put(db, 'last_success', now)
        put(db, 'last_error', '')
    print('Forwarding check completed. Flagged posts remain isolated for review.', flush=True)


def revision(db, pid):
    row = db.execute('SELECT status,payload FROM posts WHERE id=?', (pid,)).fetchone()
    deliveries = [tuple(item) for item in db.execute('SELECT part,status,message_id FROM deliveries WHERE post_id=? ORDER BY part', (pid,))]
    return hashlib.sha256(json.dumps([row[0] if row else None, deliveries, get(db, 'manual_generation_'+pid),
                                     hashlib.sha256(row[1].encode()).hexdigest() if row else None]).encode()).hexdigest()


def process_request(db, request, call, now):
    """Only fixed post operations, serialized with the automatic worker's lock."""
    rid, pid = request['id'], request['post_id']
    if db.execute('SELECT 1 FROM manual_requests WHERE id=?', (rid,)).fetchone():
        return
    with db:
        db.execute('INSERT INTO manual_requests VALUES(?,?,?,?,?,?,?,NULL)',
                   (rid, pid, request['actor'], request['action'], 'processing', '', now))
    try:
        row = db.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone()
        if row is None:
            raise Failure('post_not_found')
        if revision(db, pid) != request['revision']:
            raise Failure('post_changed_refresh')
        if row['status'] == 'sent' and request['action'] not in ('republish','publish_media'):
            raise Failure('already_sent')
        if request['action']=='publish_media' and (row['status']!='sent' or not missing_media(db,pid)):
            raise Failure('no_missing_media')
        if request['action'] == 'republish' and (row['status'] != 'sent' or request.get('confirmed') is not True):
            raise Failure('confirm_republish_completed_post')
        with db:
            put(db, 'manual_generation_'+pid, int(get(db, 'manual_generation_'+pid))+1)
        if now < float(get(db, 'next_send')):
            raise Failure('manual_rate_limit_wait')
        ambiguous = db.execute("SELECT 1 FROM deliveries WHERE post_id=? AND status IN ('sending','uncertain')", (pid,)).fetchone()
        if ambiguous and request.get('confirmed') is not True:
            raise Failure('confirm_channel_first')
        # Permission failures must leave the prior successful deliveries intact.
        preflight(call)
        if request['action'] == 'mark_sent':
            if not ambiguous:
                raise Failure('no_uncertain_parts')
            with db:
                for part in db.execute("SELECT part FROM deliveries WHERE post_id=? AND status IN ('sending','uncertain')",(pid,)).fetchall():
                    put(db,'delivery_origin_'+pid+'_'+str(part['part']),'manual_confirmed')
                db.execute("UPDATE deliveries SET status='sent' WHERE post_id=? AND status IN ('sending','uncertain')", (pid,))
        elif request['action'] == 'publish':
            with db:
                db.execute("UPDATE deliveries SET status='retry' WHERE post_id=? AND status IN ('failed','uncertain','sending')", (pid,))
        elif request['action'] == 'republish':
            with db:
                db.execute('INSERT INTO delivery_history SELECT ?,post_id,part,status,message_id,? FROM deliveries WHERE post_id=?', (rid,now,pid))
                db.execute('DELETE FROM deliveries WHERE post_id=?', (pid,))
                db.execute("UPDATE posts SET status='pending' WHERE id=?", (pid,))
        elif request['action']=='publish_media':
            pass  # Appended segments only; successful text/photo records remain intact.
        else:
            raise Failure('invalid_action')
        with db:
            db.execute("UPDATE posts SET status='pending' WHERE id=?", (pid,))
        # Uses stored validated content, never fetches X or accepts client text/URLs/tokens.
        cycle(db, [], call, now, only_post=pid)
        with db:
            db.execute("UPDATE manual_requests SET status='completed',detail='sent',completed=? WHERE id=?", (time.time(), rid))
            blocked = db.execute("SELECT 1 FROM deliveries WHERE status IN ('failed','uncertain','sending')").fetchone()
            if not blocked and ('telegram_' in get(db,'last_error','') or get(db,'last_error','').startswith('delivery_requires_inspection')):
                put(db,'last_error','')
    except Failure as error:
        with db:
            db.execute("UPDATE manual_requests SET status='failed',detail=?,completed=? WHERE id=?", (str(error), time.time(), rid))


def process_queue(db, call):
    with db:
        db.execute("UPDATE manual_requests SET status='interrupted',detail='check_channel_before_retry',completed=? WHERE status='processing'", (time.time(),))
    for path in sorted(REQUESTS.glob('*.json'))[:50]:
        if not re.fullmatch(r'[a-f0-9]{32}\.json', path.name):
            continue
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, 'rb') as stream:
                raw = stream.read(8193)
            if len(raw) > 8192:
                raise ValueError()
            request = json.loads(raw)
            if (request['id'] != path.stem or not re.fullmatch(r'\d{1,30}', request['post_id'])
                    or not re.fullmatch(r'[a-f0-9]{64}', request['revision'])
                    or request['action'] not in ('publish','mark_sent','republish','publish_media')
                    or not isinstance(request['actor'],str) or len(request['actor']) > 100):
                raise ValueError()
            process_request(db, request, call, time.time())
        except (ValueError, TypeError, KeyError, OSError):
            print('Invalid manual request ignored.', flush=True)
        finally:
            path.unlink(missing_ok=True)


def refresh_lock(lock):
    deadline=time.monotonic()+30
    while True:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            return
        except BlockingIOError:
            if time.monotonic()>=deadline:raise Failure('worker_busy_retry_later') from None
            time.sleep(.2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('initialize', 'run', 'status', 'preflight', 'manual','refresh-media'))
    parser.add_argument('--post-id')
    args = parser.parse_args()
    if args.action=='refresh-media' and not args.post_id:raise Failure('invalid_post_id')
    token = os.environ.get('TG_BOT_TOKEN', '')
    call = lambda method, data: telegram(token, method, data)
    if args.action == 'preflight':
        preflight(call)
        print('Verified bot identity and channel posting permission; no message sent.')
        return
    STATE.mkdir(mode=0o700, parents=True, exist_ok=True)
    with (STATE / 'worker.lock').open('a') as lock:
        if args.action=='refresh-media':refresh_lock(lock)
        else:fcntl.flock(lock, fcntl.LOCK_EX if args.action == 'manual' else fcntl.LOCK_EX | fcntl.LOCK_NB)
        with closing(connect(STATE / 'forward.sqlite3')) as db:
            with db:
                db.execute("UPDATE manual_requests SET status='interrupted',detail='check_channel_before_retry',completed=? WHERE status='processing'", (time.time(),))
            if args.action == 'manual':
                process_queue(db, call)
                return
            if args.action=='refresh-media':
                result=refresh_media(db,args.post_id,time.time())
                print('Media refreshed for post '+args.post_id+': '+json.dumps(result))
                print('No Telegram message sent. Use the dashboard to publish missing media.')
                return
            if args.action == 'status':
                print('Enabled at UTC:', datetime.fromtimestamp(float(get(db, 'enabled_at')), timezone.utc).isoformat())
                print('Post states:', dict(db.execute('SELECT status,COUNT(*) FROM posts GROUP BY status').fetchall()))
                print('Delivery states:', dict(db.execute('SELECT status,COUNT(*) FROM deliveries GROUP BY status').fetchall()))
                return
            now = time.time()
            if args.action == 'initialize':
                if get(db, 'enabled_at', ''):
                    print('Existing activation and delivery history preserved.')
                    return
                preflight(call)
                posts = fetch_feed()
                if not any(now - 7 * 86400 <= post['published'] <= now + 60 for post in posts):
                    raise Failure('feed_has_no_recent_posts')
                if initialize(db, posts, now):
                    print('Baseline saved. Only posts published after this activation will be sent.')
                else:
                    print('Existing activation and delivery history preserved.')
            else:
                run_once(db, call, now)


def publish_status(error=None):
    """Publish only curated public-post metadata, never credentials or raw responses."""
    if not (STATE / 'forward.sqlite3').is_file():
        return
    with closing(connect(STATE / 'forward.sqlite3')) as db:
        if error:
            with db:
                put(db, 'last_error', error)
                put(db, 'last_error_at', time.time())
        report = {'version': 1, 'updated_at': time.time(), 'source': ACCOUNT, 'channel': CHANNEL,
                  'bot': BOT, 'interval_seconds': 600,
                  'counts': dict(db.execute('SELECT status,COUNT(*) FROM posts GROUP BY status').fetchall()),
                  'delivery_counts': dict(db.execute('SELECT status,COUNT(*) FROM deliveries GROUP BY status').fetchall()),
                  'posts': []}
        report['isolated_delivery_errors'] = True
        report['delivery_origin_tracking'] = True
        report['manual_supported'] = True
        report['republish_supported'] = True
        report['animated_media_supported'] = True
        report['requests'] = [dict(item) for item in db.execute('SELECT * FROM manual_requests ORDER BY created DESC LIMIT 50')]
        for key in ('enabled_at', 'last_check', 'last_success', 'last_delivery', 'next_fetch', 'next_send', 'last_error_at', 'last_fetch_success', 'last_auto_delivery', 'last_manual_delivery'):
            report[key] = float(get(db, key))
        report['last_error'] = get(db, 'last_error', '')
        report['last_feed_error'] = get(db, 'last_feed_error', '')
        for row in db.execute('SELECT * FROM posts ORDER BY CAST(id AS INTEGER) DESC LIMIT 100'):
            post = json.loads(row['payload'])
            media=post.get('media',[])+post.get('media_extra',[])
            deliveries = [dict(item) for item in db.execute('SELECT part,status,message_id FROM deliveries WHERE post_id=? ORDER BY part', (row['id'],))]
            for delivery in deliveries:
                delivery['detail'] = get(db, 'delivery_error_'+row['id']+'_'+str(delivery['part']), '') if delivery['status']!='sent' else ''
                delivery['origin'] = get(db, 'delivery_origin_'+row['id']+'_'+str(delivery['part']), '')
            history = [dict(item) for item in db.execute('SELECT part,message_id,archived_at FROM delivery_history WHERE post_id=? ORDER BY archived_at DESC,part LIMIT 20', (row['id'],))]
            report['posts'].append({'id': row['id'], 'published': post['published'], 'text': post['text'][:1200],
                                    'images': len(post['images']), 'animations':sum(m['kind']=='animation' for m in media),
                                    'videos':sum(m['kind']=='video' for m in media),'missing_media':missing_media(db,row['id'],post),
                                    'planned_parts':len(plan(post)), 'status': row['status'], 'deliveries': deliveries,
                                    'revision':revision(db,row['id']), 'previous_deliveries':history})
    PUBLIC.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    PUBLIC.parent.chmod(0o755)
    fd, filename = tempfile.mkstemp(dir=PUBLIC.parent, prefix='.status-')
    try:
        with os.fdopen(fd, 'w') as output:
            os.fchmod(output.fileno(), 0o644)
            json.dump(report, output, ensure_ascii=False)
            output.flush()
            os.fsync(output.fileno())
        os.replace(filename, PUBLIC)
    finally:
        Path(filename).unlink(missing_ok=True)


if __name__ == '__main__':
    os.umask(0o077)
    failure = None
    try:
        main()
    except BlockingIOError:
        print('Another forwarding operation is active; check deferred.', flush=True)
    except (Failure, OSError, ValueError, sqlite3.Error) as error:
        # API errors can include token-bearing URLs. Never print arbitrary exceptions.
        failure = str(error) if isinstance(error, Failure) else 'local_runtime_error'
        print('Stopped: ' + failure, flush=True)
        raise SystemExit(1)
    finally:
        if len(sys.argv) > 1 and sys.argv[1] in ('run', 'initialize', 'manual','refresh-media'):
            try:
                publish_status(failure)
            except (OSError, ValueError, sqlite3.Error):
                print('Status report could not be published.', flush=True)
