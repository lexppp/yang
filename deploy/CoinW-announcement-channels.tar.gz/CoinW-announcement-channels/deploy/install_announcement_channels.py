#!/usr/bin/env python3
"""Install announcement channels and multi-target publishing without changing accounts or other tools."""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request

SOURCE=Path(__file__).resolve().parents[1]
APP=Path('/opt/coinw')
CONFIG=Path('/etc/coinw/coinw.env')
BACKUPS=Path('/var/lib/coinw/code-backups')
DATA=Path('/var/lib/coinw')
NAMES={'app.py','community_runtime.py','static/live-announcements.js',
       'deploy/install_announcement_channels.py','deploy/ANNOUNCEMENT_CHANNELS.md'}


def command(args):
    result=subprocess.run(args,capture_output=True,timeout=45)
    if result.returncode:raise ValueError('Service operation failed. Check the coinw service status.')


def atomic(path,body):
    fd,temporary=tempfile.mkstemp(dir=path.parent,prefix='.announcement-update-')
    try:
        with os.fdopen(fd,'wb') as stream:
            os.fchmod(stream.fileno(),0o644);stream.write(body);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
    finally:Path(temporary).unlink(missing_ok=True)


def database_path():
    database=DATA/'community.sqlite3'
    for line in CONFIG.read_text().splitlines():
        if line.startswith('DATABASE_PATH='):
            database=Path(line.split('=',1)[1].strip().strip('"').strip("'"))
            if not database.is_absolute():database=APP/database
            break
    if database.is_symlink() or database.resolve().parent!=DATA.resolve() or not database.is_file():
        raise ValueError('Expected an existing business database under /var/lib/coinw.')
    return database


def readiness(asset,database):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(50):
        try:
            with opener.open('http://127.0.0.1:8000/health',timeout=1) as response:
                if json.load(response).get('ok'):break
        except OSError:time.sleep(.2)
    else:raise ValueError('Website readiness failed; restoring previous code.')
    with opener.open('http://127.0.0.1:8000/live-announcements.js',timeout=3) as response:
        if response.read(200000)!=asset:raise ValueError('Updated page was not served; restoring previous code.')
    with closing(sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True)) as db:
        columns={row[1] for row in db.execute('PRAGMA table_info(announcement_plans)')}
        if not {'buttons','button_columns'}<=columns:raise ValueError('Announcement schema migration was not applied.')


def install():
    if os.geteuid()!=0:raise ValueError('Run sudo python3 deploy/install_announcement_channels.py')
    manifest=json.loads((SOURCE/'deploy/announcement-channels-release.json').read_text())
    if manifest.get('version')!=1 or set(manifest.get('files',{}))!=NAMES:raise ValueError('Unexpected bundle manifest.')
    contents={}
    for name,digest in manifest['files'].items():
        body=(SOURCE/name).read_bytes()
        if hashlib.sha256(body).hexdigest()!=digest:raise ValueError('Bundle checksum mismatch; nothing installed.')
        if name.endswith('.py'):compile(body,name,'exec')
        contents[name]=body
    targets={APP/name:contents[name] for name in ('app.py','community_runtime.py','static/live-announcements.js')}
    for path in (*targets,APP/'app.py'):
        if path.is_symlink() or not path.is_file():raise ValueError('Expected the existing CoinW website installation.')
    database=database_path()
    previous={path:path.read_bytes() for path in targets}
    was_active=subprocess.run(['systemctl','is-active','--quiet','coinw'],capture_output=True).returncode==0
    backup=BACKUPS/('announcement-channels-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'))
    backup.mkdir(parents=True,mode=0o700)
    for index,body in enumerate(previous.values()):(backup/(str(index)+'.bin')).write_bytes(body)
    (backup/'files.json').write_text(json.dumps([str(path) for path in previous]))
    print('Verified announcement channel update. Preparing code and database backup.',flush=True)
    try:
        command(['systemctl','stop','coinw'])
        with closing(sqlite3.connect(database)) as source,closing(sqlite3.connect(backup/'database.sqlite3')) as target:
            source.backup(target)
        (backup/'database.sqlite3').chmod(0o600)
        for path,body in targets.items():atomic(path,body)
        command(['systemctl','start','coinw'])
        readiness(contents['static/live-announcements.js'],database)
    except BaseException:
        subprocess.run(['systemctl','stop','coinw'],capture_output=True)
        for path,body in previous.items():atomic(path,body)
        if was_active:subprocess.run(['systemctl','start','coinw'],capture_output=True)
        raise
    print('Announcement channels installed. Existing accounts, settings, plans and delivery history were preserved.')
    print('The website service was restarted. X forwarding and dialogue workers were not changed.')
    print('Open https://panel.chloehub.top/?v=announcement-channels#announcements and refresh the page.')
    print('Select a group or channel and click Check connection. Optionally select additional targets before publishing.')


if __name__=='__main__':
    os.umask(0o077)
    try:install()
    except KeyboardInterrupt:
        print('Update cancelled. Existing code was preserved or restored.',file=sys.stderr);sys.exit(130)
    except ValueError as error:
        print('Update stopped: '+str(error),file=sys.stderr);sys.exit(1)
    except Exception:
        print('Update stopped. Check existing files, database permissions and website service readiness. No credentials were displayed.',file=sys.stderr);sys.exit(1)
