# 公告频道与多目标发布升级

适用于已安装 CoinW 社群后台和对话工具的服务器。安装器只更新 app.py、community_runtime.py、static/live-announcements.js，自动备份代码与业务数据库，验证失败恢复旧代码。保留现有计划与历史记录；不更改机器人 Token、账户、X同步与对话工作进程。

频道管理员需要给本后台使用的机器人开启“发布消息”。频道置顶还需要“编辑消息”；也可取消公告的“发布后置顶”。频道不使用话题 ID。

升级后强制刷新公告页，选择目标后点击“检查连接”。检查只读取 Telegram 目标和机器人的权限，不发送测试消息。会显示当前机器人用户名，且可修复已有频道的过期连接状态。已手动解除的目标仍需在解除列表恢复连接。

勾选“同时发送到其他群组／频道”，最多选择10个目标。群组分别填写话题ID，频道留空。所有目标通过本地校验后才保存；提交发送会列出目标再次确认。每个目标单独生成计划、发送结果和置顶结果。保存后在各目标下分别编辑、暂停或取消；不会形成持续联动的批量任务。Telegram 各目标权限会实时变化，某个目标失败不撤回其他已发送的公告。结果未确认时不会自动重发，请先在 Telegram 核对。

安装：sudo python3 deploy/install_announcement_channels.py

成功标记：Announcement channels installed.

页面：https://panel.chloehub.top/?v=announcement-channels#announcements
